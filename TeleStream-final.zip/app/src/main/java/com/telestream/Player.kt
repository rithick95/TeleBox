package com.telestream

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

@Composable
fun Player(
    v: Tg.Vid,
    hasPrev: Boolean,
    hasNext: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    variants: List<Tg.Vid>,
    onSwitch: (Tg.Vid, Long) -> Unit,
    startAt: Long,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    val dl by Downloads.state.collectAsState()
    val lib = remember { LibVLC(ctx, arrayListOf("--network-caching=2500")) }
    val mp = remember { MediaPlayer(lib) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableStateOf(0L) }
    var len by remember { mutableStateOf(0L) }
    var ui by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf("") }
    var speed by remember { mutableStateOf(1f) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var hint by remember { mutableStateOf("") }
    val modes = listOf(
        "Fit" to MediaPlayer.ScaleType.SURFACE_BEST_FIT,
        "Fill (crop)" to MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
        "Stretch" to MediaPlayer.ScaleType.SURFACE_FILL,
        "16:9" to MediaPlayer.ScaleType.SURFACE_16_9,
        "4:3" to MediaPlayer.ScaleType.SURFACE_4_3,
        "Original" to MediaPlayer.ScaleType.SURFACE_ORIGINAL
    )
    val mode = Prefs.aspect.coerceIn(0, modes.size - 1)

    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val ctrl = WindowCompat.getInsetsController(act.window, act.window.decorView)
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        mp.setEventListener { ev ->
            if (ev.type == MediaPlayer.Event.EndReached) {
                Handler(Looper.getMainLooper()).post {
                    if (len > 0L) Progress.save(v, len, len)
                    if (hasNext) onNext()
                }
            }
        }
        onDispose {
            Progress.save(v, pos, len)
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            ctrl.show(WindowInsetsCompat.Type.systemBars())
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            try { mp.setEventListener(null); mp.stop(); mp.detachViews(); mp.release(); lib.release() } catch (_: Exception) {}
        }
    }
    // keep the screen on while the video is playing
    LaunchedEffect(playing) {
        if (playing) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    // apply the chosen screen fit once the video is running
    LaunchedEffect(mode, len > 0L) {
        delay(250)
        try { mp.setVideoScale(modes[mode].second) } catch (_: Exception) {}
    }
    // short on-screen message (aspect mode, +/-10 s)
    LaunchedEffect(hint) {
        if (hint != "") { delay(900); hint = "" }
    }
    // resume where you stopped
    LaunchedEffect(Unit) {
        val start = if (startAt > 0L) startAt + 3000L else Progress.resumePos(v)
        if (start > 5000L) {
            var tries = 0
            while (tries < 100 && mp.getLength() <= 0L) { delay(200); tries++ }
            if (mp.getLength() > 0L) mp.setTime((start - 3000L).coerceAtLeast(0L))
        }
    }
    // position ticker + save progress every ~10 s
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            try {
                pos = mp.getTime(); len = mp.getLength(); playing = mp.isPlaying()
                tick++
                if (tick % 20 == 0 && playing) Progress.save(v, pos, len)
            } catch (_: Exception) {}
            delay(500)
        }
    }
    // hide the controls after a few seconds while playing
    LaunchedEffect(ui, playing, drag, menu) {
        if (ui && playing && drag == null && menu == "") {
            delay(3500)
            ui = false
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
            detectTapGestures(
                onTap = { ui = !ui },
                onDoubleTap = { p ->
                    if (p.x < size.width / 2f) {
                        mp.setTime((mp.getTime() - 10000L).coerceAtLeast(0L)); hint = "-10 s"
                    } else {
                        mp.setTime(mp.getTime() + 10000L); hint = "+10 s"
                    }
                }
            )
        }
    ) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            VLCVideoLayout(c).also { layout ->
                mp.attachViews(layout, null, false, false)
                StreamServer.ensure()
                val m = Media(lib, Uri.parse(StreamServer.url(v.fileId)))
                mp.setMedia(m)
                m.release()
                mp.play()
            }
        })
        if (ui) {
            Column(
                Modifier.fillMaxSize().background(Color(0x77000000)),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                    Column(Modifier.weight(1f)) {
                        Text(v.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val ep = v.episode
                        if (ep != null) Text(ep, fontSize = 11.sp, color = Muted)
                    }
                    IconButton(onClick = {
                        val n = (mode + 1) % modes.size
                        Prefs.saveAspect(n); hint = modes[n].first
                    }) { Icon(Icons.Default.AspectRatio, null) }
                    IconButton(onClick = { menu = "quality" }) { Icon(Icons.Default.HighQuality, null) }
                    IconButton(onClick = { menu = "speed" }) { Icon(Icons.Default.Speed, null) }
                    IconButton(onClick = { menu = "audio" }) { Icon(Icons.Default.Audiotrack, null) }
                    IconButton(onClick = { menu = "subs" }) { Icon(Icons.Default.Subtitles, null) }
                    val d = dl
                    if (d == null) {
                        IconButton(onClick = { Downloads.start(ctx, v) }) { Icon(Icons.Default.Download, null) }
                    } else if (d.vid.fileId == v.fileId) {
                        Text(d.phase + " " + (d.progress * 100).toInt() + "%", fontSize = 12.sp)
                        IconButton(onClick = { Downloads.cancel() }) { Icon(Icons.Default.Close, null, tint = Accent) }
                    } else {
                        IconButton(onClick = { toast(ctx, "Another download is running") }) {
                            Icon(Icons.Default.Download, null, tint = Muted)
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onPrev, enabled = hasPrev) {
                        Icon(Icons.Default.SkipPrevious, null, Modifier.size(36.dp))
                    }
                    IconButton(onClick = { mp.setTime((mp.getTime() - 10000L).coerceAtLeast(0L)) }) {
                        Icon(Icons.Default.Replay10, null, Modifier.size(40.dp))
                    }
                    IconButton(onClick = { if (mp.isPlaying()) mp.pause() else mp.play() }, modifier = Modifier.size(80.dp)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(56.dp))
                    }
                    IconButton(onClick = { mp.setTime(mp.getTime() + 10000L) }) {
                        Icon(Icons.Default.Forward10, null, Modifier.size(40.dp))
                    }
                    IconButton(onClick = onNext, enabled = hasNext) {
                        Icon(Icons.Default.SkipNext, null, Modifier.size(36.dp))
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(fmt(pos), fontSize = 12.sp)
                    Slider(
                        value = (drag ?: if (len > 0L) pos.toFloat() / len else 0f).coerceIn(0f, 1f),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { mp.setPosition(it) }; drag = null },
                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(fmt(len), fontSize = 12.sp)
                }
            }
        }
        if (hint != "") {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    hint, fontSize = 20.sp, color = Color.White,
                    modifier = Modifier.background(Color(0x99000000), androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
    }

    if (menu == "speed") {
        AlertDialog(
            onDismissRequest = { menu = "" },
            confirmButton = { TextButton(onClick = { menu = "" }) { Text("Close") } },
            title = { Text("Playback speed") },
            text = {
                Column {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { r ->
                        TextButton(onClick = { speed = r; mp.setRate(r); menu = "" }) {
                            Text(r.toString() + "x", color = if (speed == r) Accent else Color.White)
                        }
                    }
                }
            }
        )
    } else if (menu == "quality") {
        AlertDialog(
            onDismissRequest = { menu = "" },
            confirmButton = { TextButton(onClick = { menu = "" }) { Text("Close") } },
            title = { Text("Quality") },
            text = {
                Column {
                    if (variants.size < 2) Text("Only one version of this video was found in this list.")
                    variants.forEach { x ->
                        val cur = x.msgId == v.msgId
                        TextButton(onClick = { menu = ""; if (!cur) onSwitch(x, pos) }) {
                            Text((x.quality ?: "Original") + "  ·  " + fmtSize(x.size), color = if (cur) Accent else Color.White)
                        }
                    }
                }
            }
        )
    } else if (menu != "") {
        val audio = menu == "audio"
        val tracks = (if (audio) mp.getAudioTracks() else mp.getSpuTracks())?.toList() ?: emptyList()
        AlertDialog(
            onDismissRequest = { menu = "" },
            confirmButton = { TextButton(onClick = { menu = "" }) { Text("Close") } },
            title = { Text(if (audio) "Audio track" else "Subtitles") },
            text = {
                Column {
                    if (tracks.isEmpty()) Text("No tracks found")
                    tracks.forEach { t ->
                        TextButton(onClick = {
                            if (audio) mp.setAudioTrack(t.id) else mp.setSpuTrack(t.id)
                            menu = ""
                        }) { Text(t.name) }
                    }
                }
            }
        )
    }
}

private fun qRank(q: String?): Int {
    if (q == null) return 0
    if (q.equals("4K", true)) return 2160
    return q.filter { it.isDigit() }.toIntOrNull() ?: 0
}

private fun variantKey(v: Tg.Vid): String? {
    val p = NameParser.parse(v.name)
    val t = p.title ?: return null
    return t.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "") + "|" + p.year + "|" + p.season + "|" + p.episode
}

/** Other versions (e.g. 1080p / 720p) of the same video found in the current list, best quality first. */
fun variantsOf(v: Tg.Vid, list: List<Tg.Vid>): List<Tg.Vid> {
    val k = variantKey(v) ?: return listOf(v)
    val all = list.filter { it.msgId == v.msgId || variantKey(it) == k }
    return (if (all.any { it.msgId == v.msgId }) all else all + v).distinctBy { it.msgId }.sortedByDescending { qRank(it.quality) }
}
