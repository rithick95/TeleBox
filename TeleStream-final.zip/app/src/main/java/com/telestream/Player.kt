package com.telestream

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

@Composable
fun Player(v: Tg.Vid, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    val dl by Downloads.state.collectAsState()
    val lib = remember { LibVLC(ctx, arrayListOf("--network-caching=2500")) }
    val mp = remember { MediaPlayer(lib) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableStateOf(0L) }
    var len by remember { mutableStateOf(0L) }
    var ui by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf("") }
    var drag by remember { mutableStateOf<Float?>(null) }

    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val ctrl = WindowCompat.getInsetsController(act.window, act.window.decorView)
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            ctrl.show(WindowInsetsCompat.Type.systemBars())
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            try { mp.stop(); mp.detachViews(); mp.release(); lib.release() } catch (_: Exception) {}
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            try { pos = mp.getTime(); len = mp.getLength(); playing = mp.isPlaying() } catch (_: Exception) {}
            delay(500)
        }
    }
    LaunchedEffect(ui, playing, drag, menu) {
        if (ui && playing && drag == null && menu == "") {
            delay(3500)
            ui = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).clickable { ui = !ui }) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            VLCVideoLayout(c).also { layout ->
                mp.attachViews(layout, null, false, false)
                StreamServer.ensure()
                val m = Media(lib, Uri.parse(StreamServer.url(v.fileId)))
                mp.setMedia(m)
                m.release()
                mp.play()
            }
        })
        if (ui) {
            Column(
                Modifier.fillMaxSize().background(Color(0x77000000)),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                    Text(v.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    IconButton(onClick = { menu = "audio" }) { Icon(Icons.Default.Audiotrack, null) }
                    IconButton(onClick = { menu = "subs" }) { Icon(Icons.Default.Subtitles, null) }
                    val d = dl
                    if (d == null) {
                        IconButton(onClick = { Downloads.start(ctx, v) }) { Icon(Icons.Default.Download, null) }
                    } else if (d.vid.fileId == v.fileId) {
                        Text(d.phase + " " + (d.progress * 100).toInt() + "%", fontSize = 12.sp)
                        IconButton(onClick = { Downloads.cancel() }) { Icon(Icons.Default.Close, null, tint = Accent) }
                    } else {
                        IconButton(onClick = { toast(ctx, "Another download is running") }) {
                            Icon(Icons.Default.Download, null, tint = Muted)
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { mp.setTime((mp.getTime() - 10000).coerceAtLeast(0)) }) {
                        Icon(Icons.Default.Replay10, null, Modifier.size(40.dp))
                    }
                    IconButton(onClick = { if (mp.isPlaying()) mp.pause() else mp.play() }, modifier = Modifier.size(80.dp)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(56.dp))
                    }
                    IconButton(onClick = { mp.setTime(mp.getTime() + 10000) }) {
                        Icon(Icons.Default.Forward10, null, Modifier.size(40.dp))
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(fmt(pos), fontSize = 12.sp)
                    Slider(
                        value = (drag ?: if (len > 0) pos.toFloat() / len else 0f).coerceIn(0f, 1f),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { mp.setPosition(it) }; drag = null },
                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(fmt(len), fontSize = 12.sp)
                }
            }
        }
    }

    if (menu != "") {
        val audio = menu == "audio"
        val tracks = (if (audio) mp.getAudioTracks() else mp.getSpuTracks())?.toList() ?: emptyList()
        AlertDialog(
            onDismissRequest = { menu = "" },
            confirmButton = { TextButton(onClick = { menu = "" }) { Text("Close") } },
            title = { Text(if (audio) "Audio track" else "Subtitles") },
            text = {
                Column {
                    if (tracks.isEmpty()) Text("No tracks found")
                    tracks.forEach { t ->
                        TextButton(onClick = {
                            if (audio) mp.setAudioTrack(t.id) else mp.setSpuTrack(t.id)
                            menu = ""
                        }) { Text(t.name) }
                    }
                }
            }
        )
    }
}
