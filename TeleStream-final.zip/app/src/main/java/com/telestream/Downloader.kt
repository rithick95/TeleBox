package com.telestream

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.OutputStream

fun toast(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
}

/** One download at a time, with progress and cancel. */
object Downloads {
    data class Dl(val vid: Tg.Vid, val progress: Float, val phase: String)

    val state = MutableStateFlow<Dl?>(null)
    @Volatile private var cancelled = false

    fun start(ctx: Context, v: Tg.Vid) {
        val app = ctx.applicationContext
        if (state.value != null) {
            toast(app, "A download is already running")
            return
        }
        cancelled = false
        state.value = Dl(v, 0f, "Downloading")
        CoroutineScope(Dispatchers.IO).launch {
            var ok = false
            var msg = ""
            try {
                ok = Downloader.save(app, v, { p, ph -> state.value = Dl(v, p, ph) }, { cancelled })
            } catch (e: Exception) {
                msg = e.message ?: ""
            }
            val wasCancelled = cancelled
            state.value = null
            toast(app, when {
                wasCancelled -> "Download cancelled"
                ok -> "Saved to " + Prefs.pathLabel()
                else -> "Download failed. $msg"
            })
        }
    }

    fun cancel() {
        cancelled = true
        val d = state.value
        if (d != null) Tg.cancelDownload(d.vid.fileId)
    }
}

object Downloader {
    private fun mimeFor(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    private fun openTarget(ctx: Context, name: String, mime: String): Pair<OutputStream, () -> Unit> {
        val cr = ctx.contentResolver
        val tree = Prefs.tree
        if (tree != null) {
            val t = Uri.parse(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))
            val doc = DocumentsContract.createDocument(cr, parent, mime, name)
                ?: throw RuntimeException("Cannot create a file in the chosen folder")
            val cleanup: () -> Unit = {
                try { DocumentsContract.deleteDocument(cr, doc) } catch (_: Exception) {}
            }
            return Pair(cr.openOutputStream(doc)!!, cleanup)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Gram")
        }
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw RuntimeException("Cannot create file")
        val cleanup: () -> Unit = {
            try { cr.delete(uri, null, null) } catch (_: Exception) {}
        }
        return Pair(cr.openOutputStream(uri)!!, cleanup)
    }

    /** Downloads the whole file via TDLib, then copies it to the chosen folder. Returns false if cancelled. */
    fun save(ctx: Context, v: Tg.Vid, onProgress: (Float, String) -> Unit, cancelled: () -> Boolean): Boolean {
        Tg.download(v.fileId, 0, 0, 16)
        var f = Tg.file(v.fileId)
        var idle = 0
        while (!f.local.isDownloadingCompleted) {
            if (cancelled()) {
                Tg.cancelDownload(v.fileId)
                Tg.deleteLocal(v.fileId)
                return false
            }
            onProgress(f.local.downloadedSize.toFloat() / maxOf(1L, f.size), "Downloading")
            Thread.sleep(400)
            f = Tg.file(v.fileId)
            if (!f.local.isDownloadingActive && !f.local.isDownloadingCompleted) {
                idle++
                if (idle > 4) { Tg.download(v.fileId, 0, 0, 16); idle = 0 }
            } else idle = 0
        }

        var name = v.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (name.substringAfterLast('.', "").length !in 2..4) name += ".mp4"
        val target = openTarget(ctx, name, mimeFor(name))
        val out = target.first
        val cleanup = target.second

        var complete = false
        try {
            val total = maxOf(1L, f.size)
            var done = 0L
            var lastP = 0f
            val buf = ByteArray(1 shl 16)
            FileInputStream(f.local.path).use { input ->
                out.use { o ->
                    while (true) {
                        if (cancelled()) break
                        val n = input.read(buf)
                        if (n < 0) { complete = true; break }
                        o.write(buf, 0, n)
                        done += n
                        val p = done.toFloat() / total
                        if (p - lastP >= 0.005f) { lastP = p; onProgress(p, "Saving") }
                    }
                }
            }
        } finally {
            if (!complete) cleanup()
        }
        if (complete) Tg.deleteLocal(v.fileId)
        return complete
    }
}
