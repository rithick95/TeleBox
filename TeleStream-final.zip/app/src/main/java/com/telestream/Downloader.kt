package com.telestream

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.FileInputStream

object Downloader {
    /** Downloads the whole file via TDLib, then copies it to Movies/TeleStream. */
    fun save(ctx: Context, v: Tg.Vid, onProgress: (Float) -> Unit) {
        Tg.download(v.fileId, 0, 0, 16)
        var f = Tg.file(v.fileId)
        var idle = 0
        while (!f.local.isDownloadingCompleted) {
            onProgress(f.local.downloadedSize.toFloat() / maxOf(1L, f.size))
            Thread.sleep(500)
            f = Tg.file(v.fileId)
            if (!f.local.isDownloadingActive && !f.local.isDownloadingCompleted) {
                if (++idle > 4) { Tg.download(v.fileId, 0, 0, 16); idle = 0 }
            } else idle = 0
        }
        var name = v.title.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (!name.contains('.')) name += ".mp4"
        val mime = if (name.endsWith(".mkv", true)) "video/x-matroska" else "video/mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TeleStream")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw RuntimeException("Cannot create file")
        ctx.contentResolver.openOutputStream(uri)!!.use { out ->
            FileInputStream(f.local.path).use { it.copyTo(out, 1 shl 16) }
        }
        onProgress(1f)
    }
}
