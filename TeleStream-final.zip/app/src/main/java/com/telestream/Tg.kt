package com.telestream

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

object Tg {
    private lateinit var client: Client
    private lateinit var appCtx: Context
    private var started = false
    val auth = MutableStateFlow<TdApi.AuthorizationState?>(null)
    val err = MutableStateFlow<String?>(null)

    fun start(ctx: Context) {
        if (started) return
        started = true
        appCtx = ctx.applicationContext
        Client.execute(TdApi.SetLogVerbosityLevel(1))
        client = Client.create({ o ->
            if (o is TdApi.UpdateAuthorizationState) onAuth(o.authorizationState)
        }, null, null)
    }

    private fun onAuth(s: TdApi.AuthorizationState) {
        auth.value = s
        if (s is TdApi.AuthorizationStateWaitTdlibParameters) {
            val p = TdApi.SetTdlibParameters()
            p.databaseDirectory = appCtx.filesDir.absolutePath + "/td"
            p.filesDirectory = appCtx.cacheDir.absolutePath + "/tdfiles"
            p.databaseEncryptionKey = ByteArray(0)
            p.useFileDatabase = true
            p.useChatInfoDatabase = true
            p.useMessageDatabase = true
            p.apiId = BuildConfig.TG_API_ID
            p.apiHash = BuildConfig.TG_API_HASH
            p.systemLanguageCode = "en"
            p.deviceModel = "Android"
            p.applicationVersion = "1.0"
            fire(p)
        }
    }

    private fun fire(f: TdApi.Function<*>) {
        client.send(f) { if (it is TdApi.Error) err.value = it.message }
    }

    fun sendPhone(p: String) { err.value = null; fire(TdApi.SetAuthenticationPhoneNumber(p, null)) }
    fun sendCode(c: String) { err.value = null; fire(TdApi.CheckAuthenticationCode(c)) }
    fun sendPassword(p: String) { err.value = null; fire(TdApi.CheckAuthenticationPassword(p)) }

    fun <T : TdApi.Object> call(f: TdApi.Function<T>): T {
        val fut = CompletableFuture<TdApi.Object>()
        client.send(f) { fut.complete(it) }
        val r = fut.get(60, TimeUnit.SECONDS)
        if (r is TdApi.Error) throw RuntimeException(r.message)
        @Suppress("UNCHECKED_CAST")
        return r as T
    }

    // ---------- chats / topics ----------
    data class ChatItem(val id: Long, val title: String, val forum: Boolean)
    data class Topic(val threadId: Long, val name: String)
    data class Vid(val msgId: Long, val title: String, val fileId: Int, val size: Long, val duration: Int, val date: Int)

    fun chats(): List<ChatItem> {
        try { call(TdApi.LoadChats(TdApi.ChatListMain(), 200)) } catch (_: Exception) {}
        val ids = call(TdApi.GetChats(TdApi.ChatListMain(), 200)).chatIds
        return ids.map { id ->
            val c = call(TdApi.GetChat(id))
            var forum = false
            val t = c.type
            if (t is TdApi.ChatTypeSupergroup && !t.isChannel) {
                forum = try { call(TdApi.GetSupergroup(t.supergroupId)).isForum } catch (_: Exception) { false }
            }
            ChatItem(id, c.title, forum)
        }
    }

    fun topics(chatId: Long): List<Topic> {
        val r = call(TdApi.GetForumTopics(chatId, "", 0, 0, 0, 100))
        return r.topics.map { Topic(it.info.messageThreadId, it.info.name) }
    }

    private val videoExt = setOf("mkv", "mp4", "avi", "mov", "webm", "ts", "m4v", "flv", "wmv", "mpg", "mpeg", "3gp")

    class Pager(private val chatId: Long, private val thread: Long) {
        private val cursor = longArrayOf(0L, 0L)
        private val done = booleanArrayOf(false, false)
        val hasMore get() = !(done[0] && done[1])

        fun next(): List<Vid> {
            val out = ArrayList<Vid>()
            while (out.isEmpty() && hasMore) {
                for (i in 0..1) {
                    if (done[i]) continue
                    val q = TdApi.SearchChatMessages()
                    q.chatId = chatId
                    q.query = ""
                    q.fromMessageId = cursor[i]
                    q.offset = 0
                    q.limit = 50
                    q.filter = if (i == 0) TdApi.SearchMessagesFilterVideo() else TdApi.SearchMessagesFilterDocument()
                    q.messageThreadId = thread
                    val r = call(q)
                    for (m in r.messages) {
                        val c = m.content
                        if (c is TdApi.MessageVideo) {
                            val name = c.video.fileName.ifBlank { c.caption.text.take(70) }.ifBlank { "Video" }
                            out.add(Vid(m.id, name, c.video.video.id, c.video.video.size, c.video.duration, m.date))
                        } else if (c is TdApi.MessageDocument) {
                            val d = c.document
                            val ext = d.fileName.substringAfterLast('.', "").lowercase()
                            if (d.mimeType.startsWith("video/") || ext in videoExt) {
                                out.add(Vid(m.id, d.fileName.ifBlank { "Video" }, d.document.id, d.document.size, 0, m.date))
                            }
                        }
                    }
                    cursor[i] = r.nextFromMessageId
                    if (r.nextFromMessageId == 0L || r.messages.isEmpty()) done[i] = true
                }
            }
            return out.sortedByDescending { it.date }
        }
    }

    // ---------- files ----------
    fun file(id: Int): TdApi.File = call(TdApi.GetFile(id))

    fun download(id: Int, offset: Long, limit: Long = 0, prio: Int = 32) {
        client.send(TdApi.DownloadFile(id, prio, offset, limit, false)) {}
    }
}
