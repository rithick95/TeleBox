package com.telestream

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

private val qualityRx = Regex("(2160p|4k|1440p|1080p|720p|480p)", RegexOption.IGNORE_CASE)
private val epRx1 = Regex("s(\\d{1,2})\\s?[ex](\\d{1,3})", RegexOption.IGNORE_CASE)
private val epRx2 = Regex("(?:^|[\\s._\\-\\[(])(?:ep|episode|e)[\\s._\\-]?(\\d{1,3})(?=[\\s._\\-\\])]|$)", RegexOption.IGNORE_CASE)

fun cleanTitle(n: String): String {
    val ext = n.substringAfterLast('.', "")
    val noExt = if (n.contains('.') && ext.length in 2..4) n.substringBeforeLast('.') else n
    return noExt.replace('.', ' ').replace('_', ' ').replace(Regex("\\s+"), " ").trim().ifBlank { "Video" }
}

object Tg {
    private lateinit var client: Client
    private lateinit var appCtx: Context
    private var started = false
    val auth = MutableStateFlow<TdApi.AuthorizationState?>(null)
    val err = MutableStateFlow<String?>(null)

    fun start(ctx: Context) {
        if (started) return
        started = true
        appCtx = ctx.applicationContext
        Client.execute(TdApi.SetLogVerbosityLevel(1))
        client = Client.create({ o ->
            if (o is TdApi.UpdateAuthorizationState) onAuth(o.authorizationState)
        }, null, null)
    }

    private fun onAuth(s: TdApi.AuthorizationState) {
        if (s is TdApi.AuthorizationStateClosed) {
            // after logout TDLib closes: start a fresh client so the login screen shows again
            started = false
            auth.value = null
            Handler(Looper.getMainLooper()).post { start(appCtx) }
            return
        }
        auth.value = s
        if (s is TdApi.AuthorizationStateWaitTdlibParameters) {
            val p = TdApi.SetTdlibParameters()
            p.databaseDirectory = appCtx.filesDir.absolutePath + "/td"
            p.filesDirectory = appCtx.cacheDir.absolutePath + "/tdfiles"
            p.databaseEncryptionKey = ByteArray(0)
            p.useFileDatabase = true
            p.useChatInfoDatabase = true
            p.useMessageDatabase = true
            p.apiId = BuildConfig.TG_API_ID
            p.apiHash = BuildConfig.TG_API_HASH
            p.systemLanguageCode = "en"
            p.deviceModel = "Android"
            p.applicationVersion = "1.0"
            fire(p)
        }
    }

    private fun fire(f: TdApi.Function<*>) {
        client.send(f) { if (it is TdApi.Error) err.value = it.message }
    }

    fun sendPhone(p: String) { err.value = null; fire(TdApi.SetAuthenticationPhoneNumber(p, null)) }
    fun sendCode(c: String) { err.value = null; fire(TdApi.CheckAuthenticationCode(c)) }
    fun sendPassword(p: String) { err.value = null; fire(TdApi.CheckAuthenticationPassword(p)) }
    fun logout() { err.value = null; fire(TdApi.LogOut()) }

    fun <T : TdApi.Object> call(f: TdApi.Function<T>): T {
        val fut = CompletableFuture<TdApi.Object>()
        client.send(f) { fut.complete(it) }
        val r = fut.get(60, TimeUnit.SECONDS)
        if (r is TdApi.Error) throw RuntimeException(r.message)
        @Suppress("UNCHECKED_CAST")
        return r as T
    }

    fun me(): String {
        val u = call(TdApi.GetMe())
        return (u.firstName + " " + u.lastName).trim()
    }

    // ---------- chats / topics ----------
    data class ChatItem(val id: Long, val title: String, val forum: Boolean)
    data class Topic(val threadId: Long, val name: String)
    data class Vid(
        val msgId: Long,
        val name: String,
        val fileId: Int,
        val size: Long,
        val duration: Int,
        val date: Int,
        val thumbId: Int = 0,
        val mini: ByteArray? = null,
        val chatId: Long = 0L
    ) {
        val title: String get() = cleanTitle(name)
        val quality: String? get() = qualityRx.find(name)?.value?.uppercase()
        val episode: String?
            get() {
                val a = epRx1.find(name)
                if (a != null) return "S" + a.groupValues[1].toInt() + " E" + a.groupValues[2].toInt()
                val b = epRx2.find(name)
                if (b != null) return "EP " + b.groupValues[1].toInt()
                return null
            }
    }
    data class TopicInfo(val poster: Vid?, val count: Int)

    private fun chatItem(id: Long): ChatItem? {
        return try {
            val c = call(TdApi.GetChat(id))
            var forum = false
            val t = c.type
            if (t is TdApi.ChatTypeSupergroup && !t.isChannel) {
                forum = try { call(TdApi.GetSupergroup(t.supergroupId)).isForum } catch (_: Exception) { false }
            }
            ChatItem(id, c.title, forum)
        } catch (e: Exception) {
            null
        }
    }

    fun chats(): List<ChatItem> {
        val all = LinkedHashMap<Long, ChatItem>()
        for (list in listOf<TdApi.ChatList>(TdApi.ChatListMain(), TdApi.ChatListArchive())) {
            for (k in 0 until 15) {
                try { call(TdApi.LoadChats(list, 100)) } catch (e: Exception) { break }
            }
            val ids = try { call(TdApi.GetChats(list, 1000)).chatIds } catch (e: Exception) { LongArray(0) }
            for (id in ids) {
                if (all.containsKey(id)) continue
                val item = chatItem(id)
                if (item != null) all[id] = item
            }
        }
        return all.values.toList()
    }

    /** Opens a pasted t.me link (public name, invite link, or topic link). Returns the chat and a topic id (0 if none). */
    fun resolveLink(input: String): Pair<ChatItem, Long> {
        val s = input.trim()
        val parts = s.removePrefix("https://").removePrefix("http://").removePrefix("t.me/")
            .removePrefix("telegram.me/").substringBefore('?').trim('/').split('/')
        var topic = 0L
        val chatId: Long
        if (parts[0] == "c" && parts.size >= 2) {
            chatId = ("-100" + parts[1]).toLong()
            if (parts.size >= 3) topic = parts[2].toLongOrNull() ?: 0L
        } else if (parts[0].startsWith("+") || parts[0] == "joinchat") {
            val info = call(TdApi.CheckChatInviteLink(s))
            if (info.chatId == 0L) {
                throw RuntimeException("This account is not a member of that group yet. Open the link in Telegram, join it, then try again.")
            }
            chatId = info.chatId
        } else {
            chatId = call(TdApi.SearchPublicChat(parts[0].removePrefix("@"))).id
            if (parts.size >= 2) topic = parts[1].toLongOrNull() ?: 0L
        }
        val item = chatItem(chatId) ?: throw RuntimeException("Could not open that chat with this account.")
        return Pair(item, topic)
    }

    fun topics(chatId: Long): List<Topic> {
        val r = call(TdApi.GetForumTopics(chatId, "", 0, 0, 0, 100))
        return r.topics.map { Topic(it.info.forumTopicId.toLong(), it.info.name) }
    }

    private val videoExt = setOf("mkv", "mp4", "avi", "mov", "webm", "ts", "m4v", "flv", "wmv", "mpg", "mpeg", "3gp")

    fun parseVid(m: TdApi.Message, chatId: Long): Vid? {
        val c = m.content
        if (c is TdApi.MessageVideo) {
            val vd = c.video
            val name = vd.fileName.ifBlank { c.caption.text.take(70) }.ifBlank { "Video" }
            return Vid(m.id, name, vd.video.id, vd.video.size, vd.duration, m.date,
                vd.thumbnail?.file?.id ?: 0, vd.minithumbnail?.data, chatId)
        } else if (c is TdApi.MessageDocument) {
            val d = c.document
            val ext = d.fileName.substringAfterLast('.', "").lowercase()
            if (d.mimeType.startsWith("video/") || ext in videoExt) {
                return Vid(m.id, d.fileName.ifBlank { "Video" }, d.document.id, d.document.size, 0, m.date,
                    d.thumbnail?.file?.id ?: 0, d.minithumbnail?.data, chatId)
            }
        }
        return null
    }

    fun getVid(chatId: Long, msgId: Long): Vid? {
        return try { parseVid(call(TdApi.GetMessage(chatId, msgId)), chatId) } catch (e: Exception) { null }
    }

    fun isForum(chatId: Long): Boolean {
        return try {
            val c = call(TdApi.GetChat(chatId))
            val t = c.type
            t is TdApi.ChatTypeSupergroup && !t.isChannel && call(TdApi.GetSupergroup(t.supergroupId)).isForum
        } catch (e: Exception) {
            false
        }
    }

    /** Poster video and video count for one topic (used for the series cards). */
    fun topicInfo(chatId: Long, topicId: Long): TopicInfo {
        var poster: Vid? = null
        var count = 0
        try {
            val q = TdApi.SearchChatMessages()
            q.chatId = chatId
            q.query = ""
            q.fromMessageId = 0L
            q.offset = 0
            q.limit = 1
            q.filter = TdApi.SearchMessagesFilterVideo()
            if (topicId != 0L) q.topicId = TdApi.MessageTopicForum(topicId.toInt())
            val r = call(q)
            count = r.totalCount
            for (m in r.messages) { if (poster == null) poster = parseVid(m, chatId) }
        } catch (e: Exception) {}
        if (poster == null) {
            try {
                val q = TdApi.SearchChatMessages()
                q.chatId = chatId
                q.query = ""
                q.fromMessageId = 0L
                q.offset = 0
                q.limit = 10
                q.filter = TdApi.SearchMessagesFilterDocument()
                if (topicId != 0L) q.topicId = TdApi.MessageTopicForum(topicId.toInt())
                val r = call(q)
                for (m in r.messages) { if (poster == null) poster = parseVid(m, chatId) }
            } catch (e: Exception) {}
        }
        return TopicInfo(poster, count)
    }

    class Pager(private val chatId: Long, private val thread: Long) {
        private val cursor = longArrayOf(0L, 0L)
        private val done = booleanArrayOf(false, false)
        val hasMore get() = !(done[0] && done[1])

        @Synchronized
        fun next(): List<Vid> {
            val out = ArrayList<Vid>()
            while (out.isEmpty() && hasMore) {
                for (i in 0..1) {
                    if (done[i]) continue
                    val q = TdApi.SearchChatMessages()
                    q.chatId = chatId
                    q.query = ""
                    q.fromMessageId = cursor[i]
                    q.offset = 0
                    q.limit = 50
                    q.filter = if (i == 0) TdApi.SearchMessagesFilterVideo() else TdApi.SearchMessagesFilterDocument()
                    if (thread != 0L) q.topicId = TdApi.MessageTopicForum(thread.toInt())
                    val r = call(q)
                    for (m in r.messages) {
                        val v = parseVid(m, chatId)
                        if (v != null) out.add(v)
                    }
                    cursor[i] = r.nextFromMessageId
                    if (r.nextFromMessageId == 0L || r.messages.isEmpty()) done[i] = true
                }
            }
            return out.sortedByDescending { it.date }
        }
    }

    // ---------- files ----------
    fun file(id: Int): TdApi.File = call(TdApi.GetFile(id))

    fun download(id: Int, offset: Long, limit: Long = 0, prio: Int = 32) {
        client.send(TdApi.DownloadFile(id, prio, offset, limit, false)) {}
    }

    fun cancelDownload(id: Int) { client.send(TdApi.CancelDownloadFile(id, false)) {} }
    fun deleteLocal(id: Int) { client.send(TdApi.DeleteFile(id)) {} }
}
