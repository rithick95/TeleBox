package com.telestream

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tg.start(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFE50914))) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

class Vm : ViewModel() {
    var screen by mutableStateOf("chats")
    var title by mutableStateOf("Chats")
    var chats by mutableStateOf(listOf<Tg.ChatItem>())
    var topics by mutableStateOf(listOf<Tg.Topic>())
    var videos by mutableStateOf(listOf<Tg.Vid>())
    var hasMore by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var chat: Tg.ChatItem? = null
    var video: Tg.Vid? = null
    private var pager: Tg.Pager? = null

    private fun bg(block: () -> Unit) {
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { Tg.err.value = e.message } finally { busy = false }
        }
    }

    fun loadChats() = bg { chats = Tg.chats() }

    fun openChat(c: Tg.ChatItem) {
        chat = c; title = c.title
        if (c.forum) { screen = "topics"; topics = emptyList(); bg { topics = Tg.topics(c.id) } }
        else openVideos(0L)
    }

    fun openVideos(thread: Long) {
        val c = chat ?: return
        pager = Tg.Pager(c.id, thread)
        videos = emptyList(); screen = "videos"; more()
    }

    fun more() {
        val p = pager ?: return
        bg { videos = videos + p.next(); hasMore = p.hasMore }
    }

    fun play(v: Tg.Vid) { video = v; screen = "player" }

    fun back() {
        screen = when (screen) {
            "player" -> "videos"
            "videos" -> if (chat?.forum == true) "topics" else "chats"
            else -> "chats"
        }
        if (screen == "chats") title = "Chats"
    }
}

@Composable
fun App(vm: Vm = viewModel()) {
    val st by Tg.auth.collectAsState()
    val err by Tg.err.collectAsState()
    when (st) {
        is TdApi.AuthorizationStateWaitPhoneNumber -> Login("Phone number (with country code)", "Send code", err) { Tg.sendPhone(it) }
        is TdApi.AuthorizationStateWaitCode -> Login("Login code from Telegram", "Verify", err) { Tg.sendCode(it) }
        is TdApi.AuthorizationStateWaitPassword -> Login("2-step verification password", "Verify", err, true) { Tg.sendPassword(it) }
        is TdApi.AuthorizationStateReady -> Home(vm)
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
fun Login(label: String, btn: String, err: String?, password: Boolean = false, onSubmit: (String) -> Unit) {
    var t by remember(label) { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Image(
            painterResource(R.drawable.logo), null,
            Modifier.size(140.dp).align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "TeleStream", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            t, { t = it }, label = { Text(label) }, singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSubmit(t.trim()) }, modifier = Modifier.fillMaxWidth()) { Text(btn) }
        err?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun Home(vm: Vm) {
    val err by Tg.err.collectAsState()
    LaunchedEffect(Unit) { vm.loadChats() }
    BackHandler(vm.screen != "chats") { vm.back() }
    if (vm.screen == "player") {
        Player(vm.video!!) { vm.back() }
        return
    }
    Column(Modifier.fillMaxSize().padding(top = 36.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(vm.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), maxLines = 1)
            if (vm.busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
        LazyColumn(Modifier.fillMaxSize()) {
            when (vm.screen) {
                "chats" -> items(vm.chats) { c ->
                    Text(
                        c.title + if (c.forum) "   (topics)" else "",
                        Modifier.fillMaxWidth().clickable { vm.openChat(c) }.padding(16.dp)
                    )
                }
                "topics" -> items(vm.topics) { t ->
                    Text(t.name, Modifier.fillMaxWidth().clickable { vm.openVideos(t.threadId) }.padding(16.dp))
                }
                else -> {
                    items(vm.videos) { v ->
                        Column(Modifier.fillMaxWidth().clickable { vm.play(v) }.padding(16.dp)) {
                            Text(v.title, maxLines = 2)
                            Text(
                                fmtSize(v.size) + if (v.duration > 0) "  •  " + fmt(v.duration * 1000L) else "",
                                style = MaterialTheme.typography.bodySmall, color = Color.Gray
                            )
                        }
                    }
                    if (vm.hasMore && !vm.busy) item {
                        TextButton(onClick = { vm.more() }, modifier = Modifier.fillMaxWidth()) { Text("Load more") }
                    }
                }
            }
        }
    }
}

fun fmtSize(b: Long): String =
    if (b >= 1L shl 30) "%.2f GB".format(b / 1073741824.0) else "%.0f MB".format(b / 1048576.0)

fun fmt(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Player(v: Tg.Vid, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    val lib = remember { LibVLC(ctx, arrayListOf("--network-caching=2500")) }
    val mp = remember { MediaPlayer(lib) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableStateOf(0L) }
    var len by remember { mutableStateOf(0L) }
    var ui by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf("") }
    var dl by remember { mutableStateOf(-1f) }
    var drag by remember { mutableStateOf<Float?>(null) }

    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            try { mp.stop(); mp.detachViews(); mp.release(); lib.release() } catch (_: Exception) {}
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            try { pos = mp.getTime(); len = mp.getLength(); playing = mp.isPlaying() } catch (_: Exception) {}
            delay(500)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).clickable { ui = !ui }) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            VLCVideoLayout(c).also { layout ->
                mp.attachViews(layout, null, false, false)
                StreamServer.ensure()
                val m = Media(lib, Uri.parse(StreamServer.url(v.fileId)))
                mp.setMedia(m)
                m.release()
                mp.play()
            }
        })
        if (ui) {
            Column(Modifier.fillMaxSize().background(Color(0x66000000)), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                    Text(v.title, maxLines = 1, modifier = Modifier.weight(1f))
                    IconButton(onClick = { menu = "audio" }) { Icon(Icons.Default.Audiotrack, null) }
                    IconButton(onClick = { menu = "subs" }) { Icon(Icons.Default.Subtitles, null) }
                    if (dl < 0f) {
                        IconButton(onClick = {
                            CoroutineScope(Dispatchers.IO).launch {
                                dl = 0f
                                val ok = try { Downloader.save(ctx, v) { dl = it }; true } catch (e: Exception) { false }
                                dl = -1f
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(ctx, if (ok) "Saved to Movies/TeleStream" else "Download failed", Toast.LENGTH_LONG).show()
                                }
                            }
                        }) { Icon(Icons.Default.Download, null) }
                    } else Text("${(dl * 100).toInt()}%", modifier = Modifier.padding(horizontal = 8.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { mp.setTime((mp.getTime() - 10000).coerceAtLeast(0)) }) {
                        Icon(Icons.Default.Replay10, null, Modifier.size(40.dp))
                    }
                    IconButton(onClick = { if (mp.isPlaying()) mp.pause() else mp.play() }, modifier = Modifier.size(80.dp)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(56.dp))
                    }
                    IconButton(onClick = { mp.setTime(mp.getTime() + 10000) }) {
                        Icon(Icons.Default.Forward10, null, Modifier.size(40.dp))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(fmt(pos))
                    Slider(
                        value = (drag ?: if (len > 0) pos.toFloat() / len else 0f).coerceIn(0f, 1f),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { mp.setPosition(it) }; drag = null },
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(fmt(len))
                }
            }
        }
    }

    if (menu != "") {
        val audio = menu == "audio"
        val tracks = (if (audio) mp.getAudioTracks() else mp.getSpuTracks())?.toList() ?: emptyList()
        AlertDialog(
            onDismissRequest = { menu = "" },
            confirmButton = { TextButton(onClick = { menu = "" }) { Text("Close") } },
            title = { Text(if (audio) "Audio track" else "Subtitles") },
            text = {
                Column {
                    if (tracks.isEmpty()) Text("No tracks found")
                    tracks.forEach { t ->
                        TextButton(onClick = {
                            if (audio) mp.setAudioTrack(t.id) else mp.setSpuTrack(t.id)
                            menu = ""
                        }) { Text(t.name) }
                    }
                }
            }
        )
    }
}
