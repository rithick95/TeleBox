package com.telestream

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

val Accent = Color(0xFFE50914)
val Bg = Color(0xFF0B0B0F)
val Panel = Color(0xFF16161C)
val Muted = Color(0xFF8A8A96)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Prefs.init(this)
        Progress.init(this)
        Meta.init(this)
        Tg.start(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Bg,
                    onBackground = Color.White, onSurface = Color.White, surfaceVariant = Panel
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

class Vm : ViewModel() {
    // library, series, player, settings, picker
    var screen by mutableStateOf("library")
    var chats by mutableStateOf(listOf<Tg.ChatItem>())
    var topics by mutableStateOf(listOf<Tg.Topic>())
    var videos by mutableStateOf(listOf<Tg.Vid>())
    var recent by mutableStateOf(listOf<Tg.Vid>())
    var isForum by mutableStateOf(false)
    var rootReady by mutableStateOf(false)
    var seriesName by mutableStateOf("")
    var seriesId by mutableLongStateOf(0L)
    var hasMore by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var loadingAll by mutableStateOf(false)
    var sort by mutableIntStateOf(0)          // 0 newest, 1 oldest, 2 name
    var query by mutableStateOf("")
    var searching by mutableStateOf(false)
    var video by mutableStateOf<Tg.Vid?>(null)
    var playIdx by mutableIntStateOf(-1)
    var playlist: List<Tg.Vid> = emptyList()
    var chat: Tg.ChatItem? = null
    val posters = mutableStateMapOf<Long, Tg.TopicInfo>()
    val rootState = LazyGridState()
    var epState by mutableStateOf(LazyGridState())

    private var pager: Tg.Pager? = null
    private var loadedKey = ""
    private var chatsLoaded = false
    private var gen = 0
    private var returnScreen = "library"

    private fun bg(block: () -> Unit) {
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { Tg.err.value = e.message } finally { busy = false }
        }
    }

    // ---------- chat picker ----------
    fun loadChats() {
        if (chatsLoaded) return
        bg { chats = Tg.chats(); chatsLoaded = true }
    }

    fun reloadChats() {
        chatsLoaded = false
        loadChats()
    }

    fun pickChat(c: Tg.ChatItem) {
        chat = c
        Prefs.setSource(c.id, c.title, 0L, "")
        screen = "library"
    }

    fun openLink(text: String) {
        bg {
            val r = Tg.resolveLink(text)
            val c = r.first
            val tid = r.second
            chat = c
            val topicPath = tid != 0L && Tg.isForum(c.id)
            loadedKey = if (topicPath) c.id.toString() else ""
            Prefs.setSource(c.id, c.title, 0L, "")
            if (topicPath) {
                val tl = Tg.topics(c.id)
                gen++
                topics = tl
                isForum = true
                posters.clear()
                videos = emptyList()
                rootReady = true
                val nm = tl.firstOrNull { it.threadId == tid }?.name ?: ("Topic " + tid)
                openSeries(Tg.Topic(tid, nm))
            } else {
                screen = "library"
            }
        }
    }

    // ---------- library root (series grid, or videos when the chat has no topics) ----------
    fun ensureLibrary() {
        if (!Prefs.hasSource()) return
        val key = Prefs.chatId.toString()
        if (key == loadedKey) return
        loadedKey = key
        reloadRoot()
    }

    fun reloadRoot() {
        gen++
        val g = gen
        videos = emptyList()
        topics = emptyList()
        posters.clear()
        hasMore = false
        rootReady = false
        loadingAll = false
        sort = 0
        query = ""
        searching = false
        val id = Prefs.chatId
        bg {
            try {
                val forum = Tg.isForum(id)
                if (g != gen) return@bg
                if (forum) {
                    val t = Tg.topics(id)
                    if (g == gen) { topics = t; isForum = true }
                } else {
                    val p = Tg.Pager(id, 0L)
                    pager = p
                    val n = p.next()
                    if (g == gen) { isForum = false; videos = n; hasMore = p.hasMore }
                }
            } finally {
                if (g == gen) rootReady = true
            }
            refreshRecent()
        }
    }

    // ---------- one series (= one topic) ----------
    fun openSeries(t: Tg.Topic) {
        gen++
        seriesId = t.threadId
        seriesName = t.name
        videos = emptyList()
        hasMore = false
        loadingAll = false
        epState = LazyGridState()
        query = ""
        searching = false
        sort = 1
        pager = Tg.Pager(Prefs.chatId, t.threadId)
        screen = "series"
        loadAll()
    }

    fun more() {
        if (loadingAll) return
        val p = pager ?: return
        val g = gen
        bg {
            val n = p.next()
            if (g == gen) { videos = videos + n; hasMore = p.hasMore }
        }
    }

    private fun loadAll() {
        val p = pager ?: return
        val g = gen
        loadingAll = true
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                while (g == gen && p.hasMore) {
                    val n = p.next()
                    if (g == gen) videos = videos + n
                }
                if (g == gen) hasMore = false
            } catch (e: Exception) {
                Tg.err.value = e.message
            } finally {
                if (g == gen) { loadingAll = false; busy = false }
            }
        }
    }

    fun changeSort(mode: Int) {
        sort = mode
        if (mode != 0 && hasMore && !loadingAll) loadAll()
    }

    fun refreshRecent() {
        val id = Prefs.chatId
        if (id == 0L) return
        viewModelScope.launch(Dispatchers.IO) {
            val ids = Progress.recent(id)
            recent = ids.mapNotNull { Tg.getVid(id, it) }
        }
    }

    // ---------- player ----------
    fun play(v: Tg.Vid, list: List<Tg.Vid>) {
        returnScreen = if (screen == "series") "series" else "library"
        playlist = list
        playIdx = list.indexOfFirst { it.msgId == v.msgId }
        video = v
        screen = "player"
    }

    fun playNext(delta: Int) {
        val i = playIdx + delta
        if (i in playlist.indices) {
            playIdx = i
            video = playlist[i]
        }
    }

    // ---------- navigation ----------
    fun openSettings() { screen = "settings" }
    fun openPicker() { screen = "picker" }

    fun back() {
        when (screen) {
            "player" -> { screen = returnScreen; refreshRecent() }
            "series" -> {
                gen++
                loadingAll = false
                busy = false
                query = ""
                searching = false
                screen = "library"
            }
            else -> screen = "library"
        }
    }

    fun logout() {
        Tg.logout()
        Prefs.clearSource()
        gen++
        chats = emptyList(); chatsLoaded = false
        videos = emptyList(); topics = emptyList(); recent = emptyList()
        loadedKey = ""
        rootReady = false
        screen = "picker"
    }
}

@Composable
fun App(vm: Vm = viewModel()) {
    val st by Tg.auth.collectAsState()
    val err by Tg.err.collectAsState()
    when (st) {
        is TdApi.AuthorizationStateWaitPhoneNumber -> Login("Phone number (with country code)", "Send code", err) { Tg.sendPhone(it) }
        is TdApi.AuthorizationStateWaitCode -> Login("Login code from Telegram", "Verify", err) { Tg.sendCode(it) }
        is TdApi.AuthorizationStateWaitPassword -> Login("2-step verification password", "Verify", err, true) { Tg.sendPassword(it) }
        is TdApi.AuthorizationStateReady -> Home(vm)
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
    }
}

@Composable
fun Home(vm: Vm) {
    val screen = if (!Prefs.hasSource() && (vm.screen == "library" || vm.screen == "series")) "picker" else vm.screen
    LaunchedEffect(Prefs.chatId) { vm.ensureLibrary() }
    BackHandler(screen != "library" && !(screen == "picker" && !Prefs.hasSource())) { vm.back() }
    when (screen) {
        "player" -> {
            val v = vm.video
            if (v != null) {
                key(v.msgId) {
                    Player(
                        v,
                        vm.playIdx > 0,
                        vm.playIdx >= 0 && vm.playIdx < vm.playlist.size - 1,
                        { vm.playNext(-1) },
                        { vm.playNext(1) }
                    ) { vm.back() }
                }
            }
        }
        "settings" -> SettingsScreen(vm)
        "picker" -> PickerChats(vm)
        "series" -> EpisodeScreen(vm)
        else -> {
            if (!vm.rootReady) LoadingBox("Loading your library...")
            else if (vm.isForum) SeriesRoot(vm)
            else VideoLibrary(vm)
        }
    }
}
