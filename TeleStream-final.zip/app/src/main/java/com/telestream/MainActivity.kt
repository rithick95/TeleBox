package com.telestream

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

val Accent = Color(0xFFE50914)
val Bg = Color(0xFF0B0B0F)
val Panel = Color(0xFF16161C)
val Muted = Color(0xFF8A8A96)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Prefs.init(this)
        Tg.start(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Bg,
                    onBackground = Color.White, onSurface = Color.White, surfaceVariant = Panel
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

class Vm : ViewModel() {
    var screen by mutableStateOf("library")
    var chats by mutableStateOf(listOf<Tg.ChatItem>())
    var topics by mutableStateOf(listOf<Tg.Topic>())
    var videos by mutableStateOf(listOf<Tg.Vid>())
    var hasMore by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var chat: Tg.ChatItem? = null
    var video: Tg.Vid? = null
    val gridState = LazyGridState()
    private var pager: Tg.Pager? = null
    private var loadedKey = ""
    private var chatsLoaded = false
    private var gen = 0

    private fun bg(block: () -> Unit) {
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { Tg.err.value = e.message } finally { busy = false }
        }
    }

    fun loadChats() {
        if (chatsLoaded) return
        bg { chats = Tg.chats(); chatsLoaded = true }
    }

    fun ensureLibrary() {
        if (!Prefs.hasSource()) return
        val key = "${Prefs.chatId}:${Prefs.topicId}"
        if (key == loadedKey) return
        loadedKey = key
        reloadInternal()
    }

    fun reload() {
        loadedKey = "${Prefs.chatId}:${Prefs.topicId}"
        reloadInternal()
    }

    private fun reloadInternal() {
        gen++
        videos = emptyList()
        hasMore = false
        pager = Tg.Pager(Prefs.chatId, Prefs.topicId)
        more()
    }

    fun more() {
        val p = pager ?: return
        val g = gen
        bg {
            val n = p.next()
            if (g == gen) { videos = videos + n; hasMore = p.hasMore }
        }
    }

    fun pickChat(c: Tg.ChatItem) {
        chat = c
        if (c.forum) {
            topics = emptyList()
            screen = "topics"
            bg { topics = Tg.topics(c.id) }
        } else {
            Prefs.setSource(c.id, c.title, 0L, "")
            screen = "library"
        }
    }

    fun pickTopic(t: Tg.Topic?) {
        val c = chat ?: return
        Prefs.setSource(c.id, c.title, t?.threadId ?: 0L, t?.name ?: "")
        screen = "library"
    }

    fun play(v: Tg.Vid) { video = v; screen = "player" }
    fun openSettings() { screen = "settings" }
    fun openPicker() { screen = "picker" }
    fun back() { screen = if (screen == "topics") "picker" else "library" }

    fun logout() {
        Tg.logout()
        Prefs.clearSource()
        chats = emptyList(); chatsLoaded = false
        videos = emptyList(); loadedKey = ""
        screen = "picker"
    }
}

@Composable
fun App(vm: Vm = viewModel()) {
    val st by Tg.auth.collectAsState()
    val err by Tg.err.collectAsState()
    when (st) {
        is TdApi.AuthorizationStateWaitPhoneNumber -> Login("Phone number (with country code)", "Send code", err) { Tg.sendPhone(it) }
        is TdApi.AuthorizationStateWaitCode -> Login("Login code from Telegram", "Verify", err) { Tg.sendCode(it) }
        is TdApi.AuthorizationStateWaitPassword -> Login("2-step verification password", "Verify", err, true) { Tg.sendPassword(it) }
        is TdApi.AuthorizationStateReady -> Home(vm)
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
    }
}

@Composable
fun Home(vm: Vm) {
    val screen = if (!Prefs.hasSource() && vm.screen == "library") "picker" else vm.screen
    BackHandler(screen != "library" && !(screen == "picker" && !Prefs.hasSource())) { vm.back() }
    when (screen) {
        "player" -> vm.video?.let { Player(it) { vm.back() } }
        "settings" -> SettingsScreen(vm)
        "picker" -> PickerChats(vm)
        "topics" -> PickerTopics(vm)
        else -> Library(vm)
    }
}
