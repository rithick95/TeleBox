package com.telestream

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Turns a messy file name like "Show.Name.S01E02.1080p.WEB-DL.x264.mkv" into title / year / season / episode. */
object NameParser {
    data class Parsed(val title: String?, val year: Int?, val season: Int?, val episode: Int?)

    private val videoExt = Regex("""(?i)\.(mkv|mp4|avi|mov|webm|ts|m4v|flv|wmv|mpg|mpeg|3gp)$""")
    private val seRx = Regex("""(?i)\bs(\d{1,2})\s?[ex](\d{1,3})\b""")
    private val altRx = Regex("""(?i)\b(\d{1,2})x(\d{2,3})\b""")
    private val epRx = Regex("""(?i)(?:^|[\s\-])(?:episode|ep|e)\s?(\d{1,3})\b""")
    private val animeRx = Regex("""\s-\s(\d{1,4})(?:v\d)?(?=\s|$|\[|\()""")
    private val seasonRx = Regex("""(?i)\bseason\s?(\d{1,2})\b""")
    private val yearRx = Regex("""\b(19[3-9]\d|20[0-2]\d)\b""")
    private val techRx = Regex(
        """(?i)\b(2160p|1440p|1080p|1080i|720p|576p|480p|360p|4k|uhd|web[ -]?dl|webrip|blu[ -]?ray|brrip|bdrip|hdrip|hdtv|dvdrip|dvdscr|hdcam|camrip|x264|x265|h[ .]?264|h[ .]?265|hevc|remux|10bit|dual[ -]audio|amzn)\b"""
    )
    private val bracketRx = Regex("""[\[({][^\])}]*[\])}]""")
    private val symbolRx = Regex("""[^\p{L}\p{N}\s'&:-]""")
    private val spaceRx = Regex("""\s+""")

    fun parse(raw: String): Parsed {
        val s = raw.replace(videoExt, "").replace('.', ' ').replace('_', ' ')
        var cut = s.length
        var season: Int? = null
        var ep: Int? = null

        val a = seRx.find(s)
        val b = if (a == null) altRx.find(s) else null
        if (a != null) {
            season = a.groupValues[1].toIntOrNull()
            ep = a.groupValues[2].toIntOrNull()
            cut = minOf(cut, a.range.first)
        } else if (b != null) {
            season = b.groupValues[1].toIntOrNull()
            ep = b.groupValues[2].toIntOrNull()
            cut = minOf(cut, b.range.first)
        } else {
            val c = epRx.find(s) ?: animeRx.find(s)
            if (c != null) {
                ep = c.groupValues[1].toIntOrNull()
                cut = minOf(cut, c.range.first)
            }
        }
        val sm = seasonRx.find(s)
        if (sm != null) {
            if (season == null) season = sm.groupValues[1].toIntOrNull()
            cut = minOf(cut, sm.range.first)
        }

        var year: Int? = null
        val ym = yearRx.findAll(s).filter { it.range.first > 0 }.lastOrNull()
        if (ym != null) {
            year = ym.value.toIntOrNull()
            cut = minOf(cut, ym.range.first)
        }
        val t = techRx.find(s)
        if (t != null) cut = minOf(cut, t.range.first)

        val title = s.substring(0, cut)
            .replace(bracketRx, " ")
            .replace(symbolRx, " ")
            .replace(spaceRx, " ")
            .trim(' ', '-', ':')
        return Parsed(if (title.length >= 2) title else null, year, season, ep)
    }
}

/**
 * Looks up posters and proper titles on the internet.
 * Uses TMDB when a key is set (Settings or the TMDB_KEY build secret), otherwise TVMaze (series) and iTunes (movies).
 * Everything is cached in memory and on disk, so each title is only fetched once.
 */
object Meta {
    /** title = main line, subtitle = second line, poster = portrait art, wide = landscape art. */
    data class Card(val title: String, val subtitle: String?, val poster: String?, val wide: String?)

    private class Show(val id: Int, val name: String, val year: String?, val poster: String?, val backdrop: String?, val src: Int)
    private class Ep(val name: String?, val still: String?)
    private class AuthEx : Exception()

    private val NO_CARD = Card("", null, null, null)
    private val NONE = Show(-1, "", null, null, null, -1)
    private val NOEP = Ep(null, null)

    private val cardCache = ConcurrentHashMap<String, Card>()
    private val showCache = ConcurrentHashMap<String, Show>()
    private val epCache = ConcurrentHashMap<String, Ep>()
    private val locks = ConcurrentHashMap<String, Mutex>()
    private val net = Semaphore(5)
    private val imgCache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    @Volatile private var tmdbBad = false
    private lateinit var dir: File

    fun init(c: Context) {
        if (::dir.isInitialized) return
        dir = File(c.applicationContext.cacheDir, "meta")
        dir.mkdirs()
    }

    /** Forget everything (used after changing the API key or when the user taps "Clear poster cache"). */
    fun clear() {
        cardCache.clear()
        showCache.clear()
        epCache.clear()
        imgCache.evictAll()
        tmdbBad = false
        if (::dir.isInitialized) dir.listFiles()?.forEach { it.delete() }
        Prefs.metaRev++
    }

    // ------------------------------------------------------------ public lookups
    suspend fun forVideo(v: Tg.Vid, hint: String?): Card? {
        return try {
            cached("v|" + v.name + "|" + (hint ?: "")) { build(v.name, hint) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    suspend fun forSeries(name: String): Card? {
        return try {
            cached("s|$name") { buildSeries(name) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    suspend fun bitmap(url: String): Bitmap? {
        val hit = imgCache.get(url)
        if (hit != null) return hit
        return try {
            withContext(Dispatchers.IO) {
                val f = File(dir, "i_" + md5(url))
                if (!f.exists() || f.length() == 0L) {
                    net.withPermit { download(url, f) }
                }
                val b = BitmapFactory.decodeFile(f.absolutePath)
                if (b != null) imgCache.put(url, b) else f.delete()
                b
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ matching
    private suspend fun build(name: String, hint: String?): Card? {
        val p = NameParser.parse(name)
        val h = if (hint != null) NameParser.parse(hint) else null
        val ht = h?.title
        val pt = p.title

        // a file with an episode number: find the show, then the episode
        val e = p.episode
        if (e != null) {
            val cands = ArrayList<Pair<String, Int?>>()
            if (ht != null) cands.add(Pair(ht, h?.year))
            if (pt != null && (ht == null || norm(pt) != norm(ht))) cands.add(Pair(pt, p.year))
            for (c in cands) {
                val show = find("tv", c.first, c.second) ?: continue
                val s = p.season
                val ep = if (s != null) episode(show, s, e) else null
                val label = if (s != null) "S$s E$e" else "EP $e"
                val nm = ep?.name
                val title = if (nm != null) "$label · $nm" else label
                return Card(title, show.name, show.poster, ep?.still ?: show.backdrop ?: show.poster)
            }
            return null
        }

        // inside a series topic but no episode number: show the series art with the file's own title
        if (ht != null) {
            val show = find("tv", ht, h?.year)
            if (show != null) {
                return Card(pt ?: cleanTitle(name), show.name, show.poster, show.backdrop ?: show.poster)
            }
        }

        val t = pt ?: return null
        if (norm(t) == "video") return null
        val m = find("movie", t, p.year)
        if (m != null) return Card(m.name, m.year, m.poster, m.backdrop ?: m.poster)
        val tv = find("tv", t, p.year)
        if (tv != null) return Card(tv.name, tv.year, tv.poster, tv.backdrop ?: tv.poster)
        return null
    }

    private suspend fun buildSeries(name: String): Card? {
        val p = NameParser.parse(name)
        val t = p.title ?: return null
        val show = find("tv", t, p.year) ?: return null
        return Card(show.name, show.year, show.poster, show.backdrop ?: show.poster)
    }

    private suspend fun find(kind: String, title: String, year: Int?): Show? {
        val k = kind + "|" + norm(title) + "|" + (year ?: 0)
        val hit = showCache[k]
        if (hit != null) return if (hit === NONE) null else hit
        return locks.getOrPut(k) { Mutex() }.withLock {
            val again = showCache[k]
            if (again != null) {
                if (again === NONE) null else again
            } else {
                val r = net.withPermit { withContext(Dispatchers.IO) { search(kind, title, year) } }
                showCache[k] = r ?: NONE
                r
            }
        }
    }

    private suspend fun episode(show: Show, s: Int, e: Int): Ep {
        val k = "ep|" + show.src + "|" + show.id + "|" + s + "|" + e
        val hit = epCache[k]
        if (hit != null) return hit
        val r = net.withPermit { withContext(Dispatchers.IO) { fetchEpisode(show, s, e) } }
        epCache[k] = r
        return r
    }

    // ------------------------------------------------------------ cache
    private suspend fun cached(key: String, make: suspend () -> Card?): Card? {
        val m = cardCache[key]
        if (m != null) return if (m === NO_CARD) null else m
        val d = withContext(Dispatchers.IO) { readDisk(key) }
        if (d != null) {
            cardCache[key] = d
            return if (d === NO_CARD) null else d
        }
        val c = make()
        cardCache[key] = c ?: NO_CARD
        withContext(Dispatchers.IO) { writeDisk(key, c) }
        return c
    }

    private fun readDisk(key: String): Card? {
        val f = File(dir, "c_" + md5(key))
        if (!f.exists()) return null
        return try {
            val j = JSONObject(f.readText())
            if (j.length() == 0) {
                // a "no match" answer is only trusted for 3 days
                if (System.currentTimeMillis() - f.lastModified() > 3L * 24 * 3600 * 1000) {
                    f.delete()
                    null
                } else NO_CARD
            } else Card(j.optString("t"), j.str("s"), j.str("p"), j.str("w"))
        } catch (e: Exception) {
            null
        }
    }

    private fun writeDisk(key: String, c: Card?) {
        try {
            val j = JSONObject()
            if (c != null) {
                j.put("t", c.title)
                j.put("s", c.subtitle ?: "")
                j.put("p", c.poster ?: "")
                j.put("w", c.wide ?: "")
            }
            File(dir, "c_" + md5(key)).writeText(j.toString())
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ providers (blocking, call on IO)
    private fun search(kind: String, title: String, year: Int?): Show? {
        var r = searchOnce(kind, title, year)
        if (r == null && year != null) r = searchOnce(kind, title, null)
        return r
    }

    private fun searchOnce(kind: String, title: String, year: Int?): Show? {
        var r: Show? = null
        if (!tmdbBad && tmdbKey().isNotBlank()) {
            try {
                r = tmdb(kind, title, year)
            } catch (e: AuthEx) {
                tmdbBad = true
            }
        }
        if (r == null) r = if (kind == "tv") tvmaze(title, year) else itunes(title, year)
        return r
    }

    private fun tmdbKey(): String = Prefs.tmdbKey.trim().ifBlank { BuildConfig.TMDB_KEY }

    private fun tmdbImg(p: String?, size: String): String? =
        if (p == null) null else "https://image.tmdb.org/t/p/" + size + p

    private fun tmdb(kind: String, title: String, year: Int?): Show? {
        var url = "https://api.themoviedb.org/3/search/" + kind + "?include_adult=false&query=" + enc(title) +
            "&api_key=" + tmdbKey()
        if (year != null) url += (if (kind == "tv") "&first_air_date_year=" else "&year=") + year
        val body = get(url) ?: return null
        val arr = JSONObject(body).optJSONArray("results") ?: return null
        val nameKey = if (kind == "tv") "name" else "title"
        val dateKey = if (kind == "tv") "first_air_date" else "release_date"
        val n = minOf(arr.length(), 8)
        var pick: JSONObject? = null
        for (i in 0 until n) {
            val o = arr.getJSONObject(i)
            if (norm(o.optString(nameKey)) == norm(title)) { pick = o; break }
        }
        if (pick == null) {
            for (i in 0 until n) {
                val o = arr.getJSONObject(i)
                if (accept(o.optString(nameKey), title)) { pick = o; break }
            }
        }
        val o = pick ?: return null
        return Show(
            o.getInt("id"), o.optString(nameKey), o.str(dateKey)?.take(4),
            tmdbImg(o.str("poster_path"), "w500"), tmdbImg(o.str("backdrop_path"), "w780"), 0
        )
    }

    private fun tvmaze(title: String, year: Int?): Show? {
        val body = get("https://api.tvmaze.com/search/shows?q=" + enc(title)) ?: return null
        val arr = JSONArray(body)
        var pick: JSONObject? = null
        for (i in 0 until minOf(arr.length(), 6)) {
            val s = arr.getJSONObject(i).getJSONObject("show")
            if (!accept(s.optString("name"), title)) continue
            if (pick == null) pick = s
            if (year == null || s.str("premiered")?.take(4) == year.toString()) { pick = s; break }
        }
        val s = pick ?: return null
        val im = s.optJSONObject("image")
        return Show(s.getInt("id"), s.optString("name"), s.str("premiered")?.take(4), im?.str("original"), null, 1)
    }

    private fun itunes(title: String, year: Int?): Show? {
        val body = get("https://itunes.apple.com/search?media=movie&entity=movie&limit=8&term=" + enc(title)) ?: return null
        val arr = JSONObject(body).optJSONArray("results") ?: return null
        var pick: JSONObject? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!accept(o.optString("trackName"), title)) continue
            if (pick == null) pick = o
            if (year == null || o.str("releaseDate")?.take(4) == year.toString()) { pick = o; break }
        }
        val o = pick ?: return null
        val art = o.str("artworkUrl100")?.replace("100x100bb", "600x600bb")
        return Show(o.optInt("trackId"), o.optString("trackName"), o.str("releaseDate")?.take(4), art, null, 2)
    }

    private fun fetchEpisode(show: Show, s: Int, e: Int): Ep {
        if (show.src == 0) {
            return try {
                val body = get("https://api.themoviedb.org/3/tv/" + show.id + "/season/" + s + "/episode/" + e +
                    "?api_key=" + tmdbKey()) ?: return NOEP
                val o = JSONObject(body)
                Ep(o.str("name"), tmdbImg(o.str("still_path"), "w500"))
            } catch (x: AuthEx) {
                tmdbBad = true
                NOEP
            }
        }
        if (show.src == 1) {
            val body = get("https://api.tvmaze.com/shows/" + show.id + "/episodebynumber?season=" + s + "&number=" + e)
                ?: return NOEP
            val o = JSONObject(body)
            return Ep(o.str("name"), o.optJSONObject("image")?.str("original"))
        }
        return NOEP
    }

    // ------------------------------------------------------------ helpers
    private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k).ifBlank { null }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun norm(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun accept(found: String, wanted: String): Boolean {
        val a = norm(found)
        val b = norm(wanted)
        if (a.isEmpty() || b.isEmpty()) return false
        if (a == b) return true
        return a.length >= 4 && b.length >= 4 && (a.startsWith(b) || b.startsWith(a))
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** null = nothing found (404); throws on network trouble so the result is not cached. */
    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 12000
            c.setRequestProperty("User-Agent", "Stream/1.0")
            c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            if (code == 404) return null
            if (code == 401) throw AuthEx()
            if (code != 200) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun download(url: String, f: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "Stream/1.0")
            if (c.responseCode != 200) throw IOException("HTTP " + c.responseCode)
            val tmp = File(f.path + ".tmp")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(f)
        } finally {
            c.disconnect()
        }
    }
}
