package com.telestream

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.drinkless.tdlib.TdApi

object Thumbs {
    private val cache = LruCache<Int, Bitmap>(150)

    fun mini(b: ByteArray?): Bitmap? = if (b == null) null else BitmapFactory.decodeByteArray(b, 0, b.size)

    fun load(fileId: Int): Bitmap? {
        val hit = cache.get(fileId)
        if (hit != null) return hit
        return try {
            val f = Tg.call(TdApi.DownloadFile(fileId, 4, 0, 0, true))
            val path = f.local.path
            if (path.isNotEmpty()) {
                val bmp = BitmapFactory.decodeFile(path)
                if (bmp != null) cache.put(fileId, bmp)
                bmp
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
