package com.telestream

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun fmtSize(b: Long): String =
    if (b >= 1L shl 30) "%.2f GB".format(b / 1073741824.0) else "%.0f MB".format(b / 1048576.0)

fun fmt(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

// ------------------------------------------------------------------ login
@Composable
fun Login(label: String, btn: String, err: String?, password: Boolean = false, onSubmit: (String) -> Unit) {
    var t by remember(label) { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).clip(CircleShape))
        Spacer(Modifier.height(12.dp))
        Text("TELESTREAM", color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Text("Your Telegram videos, Netflix style", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            t, { t = it }, label = { Text(label) }, singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onSubmit(t.trim()) },
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(btn, fontWeight = FontWeight.Bold) }
        if (err != null) {
            Spacer(Modifier.height(12.dp))
            Text(err, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
    }
}

// ------------------------------------------------------------------ cards
@Composable
fun Thumb(v: Tg.Vid, modifier: Modifier) {
    val mini = remember(v.msgId) { Thumbs.mini(v.mini) }
    var bmp by remember(v.msgId) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(v.msgId) {
        if (v.thumbId != 0) bmp = withContext(Dispatchers.IO) { Thumbs.load(v.thumbId) }
    }
    Box(modifier.background(Color(0xFF1C1C24))) {
        val b = bmp ?: mini
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.Movie, null, Modifier.align(Alignment.Center).size(36.dp), tint = Color(0xFF444450))
        }
    }
}

@Composable
fun MetaTag(t: String, modifier: Modifier) {
    Text(
        t,
        modifier = modifier.background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
        fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold
    )
}

@Composable
fun VideoCard(v: Tg.Vid, onPlay: () -> Unit, onDownload: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onPlay)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp))) {
            Thumb(v, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))))
            Icon(
                Icons.Default.PlayArrow, null,
                Modifier.align(Alignment.Center).size(40.dp).background(Color(0x66000000), CircleShape).padding(6.dp),
                tint = Color.White
            )
            val q = v.quality
            if (q != null) MetaTag(q, Modifier.align(Alignment.TopStart).padding(6.dp))
            if (v.duration > 0) MetaTag(fmt(v.duration * 1000L), Modifier.align(Alignment.BottomEnd).padding(6.dp))
            IconButton(onClick = onDownload, modifier = Modifier.align(Alignment.TopEnd).size(38.dp)) {
                Icon(Icons.Default.Download, null, Modifier.size(20.dp), tint = Color.White)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
        Text(fmtSize(v.size), fontSize = 11.sp, color = Muted)
    }
}

@Composable
fun Hero(v: Tg.Vid, onPlay: () -> Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(16f / 10f).clip(RoundedCornerShape(16.dp)).clickable(onClick = onPlay)) {
        Thumb(v, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE0B0B0F)))))
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text("LATEST", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(4.dp))
                Text("Play", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------------------------------------ library
@Composable
fun TopBar(vm: Vm) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(36.dp).clip(CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("TELESTREAM", color = Accent, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            val sub = Prefs.chatTitle + if (Prefs.topicName.isNotBlank()) "  ›  " + Prefs.topicName else ""
            Text(sub, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (vm.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Accent)
        IconButton(onClick = { vm.reload() }) { Icon(Icons.Default.Refresh, null) }
        IconButton(onClick = { vm.openSettings() }) { Icon(Icons.Default.Settings, null) }
    }
}

@Composable
fun Library(vm: Vm) {
    val ctx = LocalContext.current
    val dl by Downloads.state.collectAsState()
    val err by Tg.err.collectAsState()
    LaunchedEffect(Prefs.chatId, Prefs.topicId) { vm.ensureLibrary() }
    val list = vm.videos
    val rest = if (list.size > 1) list.drop(1) else emptyList()

    Column(Modifier.fillMaxSize()) {
        TopBar(vm)
        val e = err
        if (e != null) {
            Text(
                e, color = MaterialTheme.colorScheme.error, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clickable { Tg.err.value = null }
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                state = vm.gridState,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 110.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (list.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) { Hero(list[0]) { vm.play(list[0]) } }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("All videos", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    }
                }
                itemsIndexed(rest) { i, v ->
                    if (i >= rest.size - 4 && vm.hasMore && !vm.busy) {
                        LaunchedEffect(rest.size) { vm.more() }
                    }
                    VideoCard(v, { vm.play(v) }, { Downloads.start(ctx, v) })
                }
                if (list.isEmpty() && !vm.busy) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            "No videos found here yet. Tap refresh, or change the source in Settings.",
                            color = Muted, modifier = Modifier.padding(24.dp)
                        )
                    }
                }
            }
            val d = dl
            if (d != null) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                        .background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.vid.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(d.phase + " " + (d.progress * 100).toInt() + "%", fontSize = 12.sp, color = Muted)
                        }
                        TextButton(onClick = { Downloads.cancel() }) { Text("Cancel", color = Accent, fontWeight = FontWeight.Bold) }
                    }
                    LinearProgressIndicator(
                        progress = { d.progress },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        color = Accent, trackColor = Color(0xFF33333D)
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ source picker
@Composable
fun ChatRow(title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).background(Accent.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
            Text(title.trim().take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = Muted)
        }
        if (sub.isNotEmpty()) Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun PickerChats(vm: Vm) {
    var q by remember { mutableStateOf("") }
    val err by Tg.err.collectAsState()
    LaunchedEffect(Unit) { vm.loadChats() }
    val shown = vm.chats.filter { it.title.contains(q, ignoreCase = true) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (Prefs.hasSource()) IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text("Choose your library", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Pick the chat or group that holds your videos", fontSize = 12.sp, color = Muted)
            }
            if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
            IconButton(onClick = { vm.reloadChats() }) { Icon(Icons.Default.Refresh, null) }
        }
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Search chats or paste a t.me link") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        val e = err
        if (e != null) Text(e, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
        val isLink = q.contains("t.me/") || q.contains("telegram.me/") || q.trim().startsWith("@")
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
            if (isLink) item { ChatRow("Open this link", q.trim()) { vm.openLink(q) } }
            items(shown) { c -> ChatRow(c.title, if (c.forum) "Has topics" else "") { vm.pickChat(c) } }
            if (!isLink) item {
                Text(
                    "Can't see your group? Paste its t.me link in the box above. The account you logged in with must be a member.",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}

@Composable
fun PickerTopics(vm: Vm) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text("Choose a topic", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(vm.chat?.title ?: "", fontSize = 12.sp, color = Muted, maxLines = 1)
            }
            if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
            item { ChatRow("All topics", "Show videos from every topic") { vm.pickTopic(null) } }
            items(vm.topics) { t -> ChatRow(t.name, "") { vm.pickTopic(t) } }
        }
    }
}

// ------------------------------------------------------------------ settings
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp, start = 4.dp)
    )
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp),
        content = content
    )
}

@Composable
fun SettingsScreen(vm: Vm) {
    val ctx = LocalContext.current
    var me by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        me = withContext(Dispatchers.IO) { try { Tg.me() } catch (e: Exception) { "" } }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            Prefs.updateTree(uri.toString())
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Section("ACCOUNT") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) {
                    Text(me.trim().take(1).uppercase().ifEmpty { "T" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(me.ifBlank { "Telegram account" }, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("Signed in", fontSize = 12.sp, color = Muted)
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(onClick = { confirm = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Log out", color = Accent, fontWeight = FontWeight.Bold)
            }
        }

        Section("LIBRARY SOURCE") {
            Text(
                Prefs.chatTitle.ifBlank { "Not set" } + if (Prefs.topicName.isNotBlank()) "  ›  " + Prefs.topicName else "",
                fontSize = 15.sp
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { vm.openPicker() },
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
            ) { Text("Change source", fontWeight = FontWeight.Bold) }
        }

        Section("DOWNLOADS") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                Text(Prefs.pathLabel(), fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { pick.launch(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Choose folder", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { Prefs.updateTree(null) }) { Text("Use default", color = Muted) }
            }
        }

        Section("ABOUT") {
            Text("TeleStream 1.0", fontSize = 14.sp)
            Text("Streams straight from Telegram. Nothing is saved unless you tap download.", fontSize = 12.sp, color = Muted)
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Log out?") },
            text = { Text("You will need to sign in again with your phone number.") },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.logout() }) { Text("Log out", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}
