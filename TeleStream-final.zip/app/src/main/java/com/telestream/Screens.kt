package com.telestream

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun fmtSize(b: Long): String =
    if (b >= 1L shl 30) "%.2f GB".format(b / 1073741824.0) else "%.0f MB".format(b / 1048576.0)

fun fmt(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

private val numRx = Regex("\\d+")
fun naturalKey(s: String): String = numRx.replace(s.lowercase()) { it.value.padStart(6, '0') }

fun sortVideos(l: List<Tg.Vid>, mode: Int): List<Tg.Vid> = when (mode) {
    1 -> l.sortedBy { it.msgId }
    2 -> l.sortedBy { naturalKey(it.name) }
    else -> l.sortedByDescending { it.msgId }
}

// ------------------------------------------------------------------ login
@Composable
fun Login(label: String, btn: String, err: String?, password: Boolean = false, onSubmit: (String) -> Unit) {
    var t by remember(label) { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).clip(CircleShape))
        Spacer(Modifier.height(12.dp))
        Text("TELESTREAM", color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
        Text("Your Telegram videos, Netflix style", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            t, { t = it }, label = { Text(label) }, singleLine = true,
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onSubmit(t.trim()) },
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(btn, fontWeight = FontWeight.Bold) }
        if (err != null) {
            Spacer(Modifier.height(12.dp))
            Text(err, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
    }
}

// ------------------------------------------------------------------ thumbnails
class CardState(val card: Meta.Card?, val done: Boolean)
class WebBmp(val bmp: android.graphics.Bitmap?, val done: Boolean)

/** Internet match (proper title + poster) for one video. done = the lookup has finished (found or not). */
@Composable
fun rememberCard(v: Tg.Vid, hint: String?, enabled: Boolean = true): CardState {
    val on = enabled && Prefs.online
    val rev = Prefs.metaRev
    val st = remember(v.msgId, v.name, hint, on, rev) { mutableStateOf(CardState(null, !on)) }
    LaunchedEffect(v.msgId, v.name, hint, on, rev) {
        if (on) st.value = CardState(Meta.forVideo(v, hint), true)
    }
    return st.value
}

@Composable
fun rememberSeriesCard(name: String): CardState {
    val on = Prefs.online
    val rev = Prefs.metaRev
    val st = remember(name, on, rev) { mutableStateOf(CardState(null, !on)) }
    LaunchedEffect(name, on, rev) {
        if (on) st.value = CardState(Meta.forSeries(name), true)
    }
    return st.value
}

@Composable
fun rememberWebBitmap(url: String?): WebBmp {
    val st = remember(url) { mutableStateOf(WebBmp(null, url == null)) }
    LaunchedEffect(url) {
        if (url != null) st.value = WebBmp(Meta.bitmap(url), true)
    }
    return st.value
}

/**
 * Poster from the internet when we found a match, otherwise the Telegram thumbnail.
 * portrait = tall poster art (series cards), otherwise wide art (episode still / backdrop).
 */
@Composable
fun Thumb(v: Tg.Vid, modifier: Modifier, hint: String? = null, portrait: Boolean = false, online: Boolean = true) {
    val mini = remember(v.msgId) { Thumbs.mini(v.mini) }
    val cs = rememberCard(v, hint, online)
    val c = cs.card
    val url = if (c == null) null else if (portrait) c.poster else (c.wide ?: c.poster)
    val web = rememberWebBitmap(url)
    val needTg = cs.done && (url == null || (web.done && web.bmp == null))
    var bmp by remember(v.msgId) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(v.msgId, needTg) {
        if (needTg && v.thumbId != 0 && bmp == null) bmp = withContext(Dispatchers.IO) { Thumbs.load(v.thumbId) }
    }
    Box(modifier.background(Color(0xFF1C1C24))) {
        val b = web.bmp ?: (if (needTg) bmp else null) ?: mini
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.Movie, null, Modifier.align(Alignment.Center).size(36.dp), tint = Color(0xFF444450))
        }
    }
}

@Composable
fun MetaTag(t: String, modifier: Modifier) {
    Text(
        t,
        modifier = modifier.background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
        fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold
    )
}

// ------------------------------------------------------------------ cards
@Composable
fun Hero(v: Tg.Vid, onPlay: () -> Unit) {
    val card = rememberCard(v, null).card
    Box(Modifier.fillMaxWidth().aspectRatio(16f / 10f).clip(RoundedCornerShape(16.dp)).clickable(onClick = onPlay)) {
        Thumb(v, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE0B0B0F)))))
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text("LATEST", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(card?.title ?: v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(4.dp))
                Text("Play", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VideoCard(v: Tg.Vid, hint: String?, onPlay: () -> Unit, onDownload: () -> Unit) {
    val f = Progress.fraction(v)
    val card = rememberCard(v, hint).card
    Column(Modifier.fillMaxWidth().clickable(onClick = onPlay)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp))) {
            Thumb(v, Modifier.fillMaxSize(), hint)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))))
            Icon(
                Icons.Default.PlayArrow, null,
                Modifier.align(Alignment.Center).size(40.dp).background(Color(0x66000000), CircleShape).padding(6.dp),
                tint = Color.White
            )
            val q = v.quality
            if (q != null) MetaTag(q, Modifier.align(Alignment.TopStart).padding(6.dp))
            Row(Modifier.align(Alignment.BottomStart).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                val ep = v.episode
                if (ep != null) MetaTag(ep, Modifier)
                if (f >= 0.95f) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.CheckCircle, null, Modifier.size(18.dp), tint = Accent)
                }
            }
            if (v.duration > 0) MetaTag(fmt(v.duration * 1000L), Modifier.align(Alignment.BottomEnd).padding(6.dp))
            IconButton(onClick = onDownload, modifier = Modifier.align(Alignment.TopEnd).size(38.dp)) {
                Icon(Icons.Default.Download, null, Modifier.size(20.dp), tint = Color.White)
            }
            if (f > 0.02f && f < 0.95f) {
                LinearProgressIndicator(
                    progress = { f },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                    color = Accent, trackColor = Color(0x55FFFFFF)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(card?.title ?: v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
        Text(
            listOfNotNull(card?.subtitle, fmtSize(v.size)).joinToString(" · "),
            maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Muted
        )
    }
}

@Composable
fun VideoRow(v: Tg.Vid, hint: String?, onPlay: () -> Unit, onDownload: () -> Unit) {
    val f = Progress.fraction(v)
    val card = rememberCard(v, hint).card
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).clickable(onClick = onPlay).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(132.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp))) {
            Thumb(v, Modifier.fillMaxSize(), hint)
            if (v.duration > 0) MetaTag(fmt(v.duration * 1000L), Modifier.align(Alignment.BottomEnd).padding(4.dp))
            if (f >= 0.95f) {
                Icon(Icons.Default.CheckCircle, null, Modifier.align(Alignment.TopStart).padding(4.dp).size(18.dp), tint = Accent)
            }
            if (f > 0.02f && f < 0.95f) {
                LinearProgressIndicator(
                    progress = { f },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                    color = Accent, trackColor = Color(0x55FFFFFF)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(card?.title ?: v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
            Text(
                listOfNotNull(card?.subtitle, v.quality, fmtSize(v.size)).joinToString(" · "),
                maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = Muted
            )
            if (card != null) {
                Text(v.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp, color = Muted)
            }
        }
        IconButton(onClick = onDownload, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Download, null, Modifier.size(20.dp), tint = Color.White)
        }
    }
}

@Composable
fun ContinueRow(vm: Vm) {
    Column(Modifier.fillMaxWidth()) {
        Text("Continue watching", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.recent) { v ->
                val f = Progress.fraction(v)
                val card = rememberCard(v, null).card
                Column(Modifier.width(230.dp).clickable { vm.play(v, vm.recent) }) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp))) {
                        Thumb(v, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))))
                        Icon(
                            Icons.Default.PlayArrow, null,
                            Modifier.align(Alignment.Center).size(40.dp).background(Color(0x66000000), CircleShape).padding(6.dp),
                            tint = Color.White
                        )
                        LinearProgressIndicator(
                            progress = { f },
                            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                            color = Accent, trackColor = Color(0x55FFFFFF)
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(card?.title ?: v.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun rememberTopicInfo(vm: Vm, t: Tg.Topic): Tg.TopicInfo? {
    val info = vm.posters[t.threadId]
    LaunchedEffect(t.threadId) {
        if (vm.posters[t.threadId] == null) {
            val r = withContext(Dispatchers.IO) { Tg.topicInfo(Prefs.chatId, t.threadId) }
            vm.posters[t.threadId] = r
        }
    }
    return info
}

/** Series art: internet poster matched by the topic name, falling back to a Telegram thumbnail. */
@Composable
fun SeriesArt(t: Tg.Topic, info: Tg.TopicInfo?, modifier: Modifier) {
    val cs = rememberSeriesCard(t.name)
    val w = rememberWebBitmap(cs.card?.poster)
    val pending = !cs.done || (cs.card?.poster != null && !w.done)
    val bmp = w.bmp
    val fb = info?.poster
    Box(modifier) {
        if (bmp != null) {
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (!pending && fb != null) {
            Thumb(fb, Modifier.fillMaxSize(), online = false)
        } else {
            Box(
                Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF3A1218), Color(0xFF14141A)))),
                contentAlignment = Alignment.Center
            ) {
                Text(t.name.trim().take(1).uppercase(), fontSize = 32.sp, fontWeight = FontWeight.Black, color = Color(0x55FFFFFF))
            }
        }
    }
}

@Composable
fun SeriesCard(vm: Vm, t: Tg.Topic) {
    val info = rememberTopicInfo(vm, t)
    val card = rememberSeriesCard(t.name).card
    Box(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(12.dp)).clickable { vm.openSeries(t) }) {
        SeriesArt(t, info, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF00B0B0F)))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(card?.title ?: t.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            val c = info?.count ?: 0
            val sub = listOfNotNull(card?.subtitle, if (c > 0) c.toString() + " videos" else null).joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
fun SeriesRow(vm: Vm, t: Tg.Topic) {
    val info = rememberTopicInfo(vm, t)
    val card = rememberSeriesCard(t.name).card
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).clickable { vm.openSeries(t) }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SeriesArt(t, info, Modifier.width(64.dp).aspectRatio(0.7f).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(card?.title ?: t.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            val c = info?.count ?: 0
            val sub = listOfNotNull(card?.subtitle, if (c > 0) c.toString() + " videos" else null).joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = Muted)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

// ------------------------------------------------------------------ shared bars
@Composable
fun LoadingBox(msg: String) {
    Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Accent)
            Spacer(Modifier.height(14.dp))
            Text(msg, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun ErrorLine() {
    val err by Tg.err.collectAsState()
    val e = err
    if (e != null) {
        Text(
            e, color = MaterialTheme.colorScheme.error, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clickable { Tg.err.value = null }
        )
    }
}

@Composable
fun SearchRow(vm: Vm) {
    if (vm.searching) {
        OutlinedTextField(
            vm.query, { vm.query = it }, singleLine = true,
            placeholder = { Text("Search") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun TopBar(
    vm: Vm, title: String, accent: Boolean, subtitle: String,
    back: Boolean, sortable: Boolean, onRefresh: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (back) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
        } else {
            Spacer(Modifier.width(8.dp))
            Image(painterResource(R.drawable.logo), null, Modifier.size(34.dp).clip(CircleShape))
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                title, color = if (accent) Accent else Color.White,
                fontSize = if (accent) 17.sp else 18.sp,
                fontWeight = if (accent) FontWeight.Black else FontWeight.Bold,
                letterSpacing = if (accent) 1.sp else 0.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (vm.busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Accent)
        IconButton(onClick = { vm.searching = !vm.searching; if (!vm.searching) vm.query = "" }, modifier = Modifier.size(40.dp)) {
            Icon(if (vm.searching) Icons.Default.Close else Icons.Default.Search, null)
        }
        IconButton(onClick = { Prefs.saveGrid(!Prefs.grid) }, modifier = Modifier.size(40.dp)) {
            Icon(if (Prefs.grid) Icons.Default.ViewList else Icons.Default.GridView, null)
        }
        if (sortable) {
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Sort, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("Newest first", "Oldest first", "Name A-Z").forEachIndexed { i, label ->
                        DropdownMenuItem(
                            text = { Text(label, color = if (vm.sort == i) Accent else Color.White) },
                            onClick = { vm.changeSort(i); menu = false }
                        )
                    }
                }
            }
        }
        if (onRefresh != null) IconButton(onClick = { onRefresh() }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Refresh, null) }
        if (!back) IconButton(onClick = { vm.openSettings() }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Settings, null) }
    }
}

@Composable
fun BoxScope.DownloadBanner() {
    val dl by Downloads.state.collectAsState()
    val d = dl
    if (d != null) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                .background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.vid.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(d.phase + " " + (d.progress * 100).toInt() + "%", fontSize = 12.sp, color = Muted)
                }
                TextButton(onClick = { Downloads.cancel() }) { Text("Cancel", color = Accent, fontWeight = FontWeight.Bold) }
            }
            LinearProgressIndicator(
                progress = { d.progress },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                color = Accent, trackColor = Color(0xFF33333D)
            )
        }
    }
}

// ------------------------------------------------------------------ library screens
@Composable
fun SeriesRoot(vm: Vm) {
    val grid = Prefs.grid
    val q = vm.query.trim()
    val shown = if (q.isEmpty()) vm.topics else vm.topics.filter { it.name.contains(q, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        TopBar(vm, "TELESTREAM", true, Prefs.chatTitle, false, false) { vm.reloadRoot() }
        SearchRow(vm)
        ErrorLine()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyVerticalGrid(
                columns = if (grid) GridCells.Adaptive(150.dp) else GridCells.Fixed(1),
                state = vm.rootState,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 110.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(if (grid) 14.dp else 8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (q.isEmpty() && vm.recent.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) { ContinueRow(vm) }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("Series", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                }
                itemsIndexed(shown) { _, t -> if (grid) SeriesCard(vm, t) else SeriesRow(vm, t) }
                if (shown.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("No topics found.", color = Muted, modifier = Modifier.padding(24.dp))
                    }
                }
            }
            DownloadBanner()
        }
    }
}

@Composable
fun TopicChips(vm: Vm) {
    val st = rememberLazyListState()
    LaunchedEffect(vm.seriesId, vm.topics.size) {
        val i = vm.topics.indexOfFirst { it.threadId == vm.seriesId }
        if (i >= 0) st.animateScrollToItem(i)
    }
    LazyRow(
        state = st,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(vm.topics) { t ->
            val sel = t.threadId == vm.seriesId
            Text(
                t.name, maxLines = 1, fontSize = 13.sp, color = Color.White,
                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.clip(RoundedCornerShape(20.dp))
                    .background(if (sel) Accent else Panel)
                    .clickable { if (!sel) vm.openSeries(t) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun VideoGrid(vm: Vm, state: LazyGridState, hero: Boolean, showRecent: Boolean) {
    val ctx = LocalContext.current
    val grid = Prefs.grid
    // inside a series topic the topic name helps match episodes to the right show
    val hint: String? = if (!hero) vm.seriesName.ifBlank { null } else null
    val sorted = remember(vm.videos, vm.sort) { sortVideos(vm.videos, vm.sort) }
    val q = vm.query.trim()
    val list = if (q.isEmpty()) sorted else sorted.filter { it.title.contains(q, ignoreCase = true) }
    val featured = if (hero && q.isEmpty() && list.isNotEmpty()) list[0] else null
    val rest = if (featured != null) list.drop(1) else list
    val resume = if (!hero && q.isEmpty()) list.firstOrNull { Progress.fraction(it) < 0.95f } else null

    LazyVerticalGrid(
        columns = if (grid) GridCells.Adaptive(160.dp) else GridCells.Fixed(1),
        state = state,
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 110.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(if (grid) 14.dp else 8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (showRecent && q.isEmpty() && vm.recent.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) { ContinueRow(vm) }
        }
        if (resume != null) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Button(
                    onClick = { vm.play(resume, list) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        (if (Progress.fraction(resume) > 0.02f) "Resume  " else "Play  ") + resume.title,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        if (featured != null) {
            item(span = { GridItemSpan(maxLineSpan) }) { Hero(featured) { vm.play(featured, list) } }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("All videos", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
        }
        itemsIndexed(rest) { i, v ->
            if (vm.sort == 0 && i >= rest.size - 4 && vm.hasMore && !vm.busy) {
                LaunchedEffect(rest.size) { vm.more() }
            }
            if (grid) VideoCard(v, hint, { vm.play(v, list) }, { Downloads.start(ctx, v) })
            else VideoRow(v, hint, { vm.play(v, list) }, { Downloads.start(ctx, v) })
        }
        if (list.isEmpty() && !vm.busy) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("No videos found here yet.", color = Muted, modifier = Modifier.padding(24.dp))
            }
        }
    }
}

@Composable
fun VideoLibrary(vm: Vm) {
    Column(Modifier.fillMaxSize()) {
        TopBar(vm, "TELESTREAM", true, Prefs.chatTitle, false, true) { vm.reloadRoot() }
        SearchRow(vm)
        ErrorLine()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            VideoGrid(vm, vm.rootState, true, true)
            DownloadBanner()
        }
    }
}

@Composable
fun EpisodeScreen(vm: Vm) {
    Column(Modifier.fillMaxSize()) {
        TopBar(vm, vm.seriesName, false, Prefs.chatTitle, true, true)
        TopicChips(vm)
        SearchRow(vm)
        ErrorLine()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.loadingAll && vm.sort != 0) {
                LoadingBox("Loading episodes... " + vm.videos.size)
            } else {
                VideoGrid(vm, vm.epState, false, false)
            }
            DownloadBanner()
        }
    }
}

// ------------------------------------------------------------------ source picker
@Composable
fun ChatRow(title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).background(Accent.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
            Text(title.trim().take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = Muted)
        }
        if (sub.isNotEmpty()) Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun PickerChats(vm: Vm) {
    var q by remember { mutableStateOf("") }
    val err by Tg.err.collectAsState()
    LaunchedEffect(Unit) { vm.loadChats() }
    val shown = vm.chats.filter { it.title.contains(q, ignoreCase = true) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (Prefs.hasSource()) IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text("Choose your library", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Pick the chat or group that holds your videos", fontSize = 12.sp, color = Muted)
            }
            if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
            IconButton(onClick = { vm.reloadChats() }) { Icon(Icons.Default.Refresh, null) }
        }
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Search chats or paste a t.me link") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        val e = err
        if (e != null) Text(e, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
        val isLink = q.contains("t.me/") || q.contains("telegram.me/") || q.trim().startsWith("@")
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
            if (isLink) item { ChatRow("Open this link", q.trim()) { vm.openLink(q) } }
            items(shown) { c -> ChatRow(c.title, if (c.forum) "Has topics" else "") { vm.pickChat(c) } }
            if (!isLink) item {
                Text(
                    "Can't see your group? Paste its t.me link in the box above. The account you logged in with must be a member.",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}

// ------------------------------------------------------------------ settings
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title, fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp, start = 4.dp)
    )
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp),
        content = content
    )
}

@Composable
fun SettingsScreen(vm: Vm) {
    val ctx = LocalContext.current
    var me by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        me = withContext(Dispatchers.IO) { try { Tg.me() } catch (e: Exception) { "" } }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            Prefs.updateTree(uri.toString())
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Section("ACCOUNT") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) {
                    Text(me.trim().take(1).uppercase().ifEmpty { "T" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(me.ifBlank { "Telegram account" }, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("Signed in", fontSize = 12.sp, color = Muted)
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(onClick = { confirm = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Log out", color = Accent, fontWeight = FontWeight.Bold)
            }
        }

        Section("LIBRARY SOURCE") {
            Text(Prefs.chatTitle.ifBlank { "Not set" }, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { vm.openPicker() },
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
            ) { Text("Change source", fontWeight = FontWeight.Bold) }
        }

        Section("DOWNLOADS") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                Text(Prefs.pathLabel(), fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { pick.launch(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Choose folder", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { Prefs.updateTree(null) }) { Text("Use default", color = Muted) }
            }
        }

        Section("POSTERS") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Fetch posters from the internet", fontSize = 14.sp)
                    Text("Titles are matched from file and topic names", fontSize = 12.sp, color = Muted)
                }
                Switch(checked = Prefs.online, onCheckedChange = { Prefs.saveOnline(it) })
            }
            Spacer(Modifier.height(14.dp))
            var key by remember { mutableStateOf(Prefs.tmdbKey) }
            OutlinedTextField(
                key, { key = it }, label = { Text("TMDB API key (optional)") }, singleLine = true,
                shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Free at themoviedb.org. Without a key TeleStream uses TVMaze and iTunes, which match fewer titles.",
                fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 6.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { Prefs.saveTmdbKey(key.trim()); Meta.clear() },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Save key", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { Meta.clear() }) { Text("Clear poster cache", color = Muted) }
            }
        }

        Section("ABOUT") {
            Text("TeleStream 1.0", fontSize = 14.sp)
            Text("Streams straight from Telegram. Nothing is saved unless you tap download.", fontSize = 12.sp, color = Muted)
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Log out?") },
            text = { Text("You will need to sign in again with your phone number.") },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.logout() }) { Text("Log out", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}
