package com.telestream

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private lateinit var sp: SharedPreferences
    var chatId by mutableLongStateOf(0L)
    var chatTitle by mutableStateOf("")
    var topicId by mutableLongStateOf(0L)
    var topicName by mutableStateOf("")
    var tree by mutableStateOf<String?>(null)
    var grid by mutableStateOf(true)
    var online by mutableStateOf(true)
    var tmdbKey by mutableStateOf("")
    var metaRev by mutableIntStateOf(0)
    var aspect by mutableIntStateOf(0)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("telestream", Context.MODE_PRIVATE)
        chatId = sp.getLong("chatId", 0L)
        chatTitle = sp.getString("chatTitle", "") ?: ""
        topicId = sp.getLong("topicId", 0L)
        topicName = sp.getString("topicName", "") ?: ""
        tree = sp.getString("tree", null)
        grid = sp.getBoolean("grid", true)
        aspect = sp.getInt("aspect", 0)
        online = sp.getBoolean("online", true)
        tmdbKey = sp.getString("tmdbKey", "") ?: ""
    }

    fun saveAspect(i: Int) { aspect = i; sp.edit().putInt("aspect", i).apply() }
    fun saveGrid(b: Boolean) { grid = b; sp.edit().putBoolean("grid", b).apply() }
    fun saveOnline(b: Boolean) { online = b; sp.edit().putBoolean("online", b).apply() }
    fun saveTmdbKey(k: String) { tmdbKey = k; sp.edit().putString("tmdbKey", k).apply() }

    fun hasSource() = chatId != 0L

    fun setSource(id: Long, title: String, tId: Long, tName: String) {
        chatId = id
        chatTitle = title
        topicId = tId
        topicName = tName
        sp.edit().putLong("chatId", id).putString("chatTitle", title)
            .putLong("topicId", tId).putString("topicName", tName).apply()
    }

    fun clearSource() = setSource(0L, "", 0L, "")

    fun updateTree(t: String?) {
        tree = t
        sp.edit().putString("tree", t).apply()
    }

    fun pathLabel(): String {
        val t = tree ?: return "Movies/Gram (default)"
        val id = Uri.parse(t).lastPathSegment ?: return "Custom folder"
        return Uri.decode(id).replace("primary:", "Internal storage/").replace(":", "/")
    }
}
