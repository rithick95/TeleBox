package com.telestream

import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.newFixedLengthResponse
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile

/** Local HTTP server: serves Telegram files to the player with Range support, downloading only what is needed. */
object StreamServer {
    private const val PORT = 8765
    private var srv: Srv? = null

    @Synchronized
    fun ensure() {
        if (srv == null) {
            val s = Srv()
            s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true)
            srv = s
        }
    }

    fun url(fileId: Int) = "http://127.0.0.1:$PORT/f/$fileId"

    private class Srv : NanoHTTPD("127.0.0.1", PORT) {
        override fun serve(session: IHTTPSession): Response {
            val id = session.uri.substringAfterLast('/').toIntOrNull()
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
            val f = Tg.file(id)
            val total = if (f.size > 0) f.size else f.expectedSize
            val range = session.headers["range"]
            var start = 0L
            var end = total - 1
            if (range != null && range.startsWith("bytes=")) {
                val p = range.removePrefix("bytes=").split("-")
                start = p[0].toLongOrNull() ?: 0L
                end = p.getOrNull(1)?.toLongOrNull() ?: (total - 1)
            }
            if (end > total - 1) end = total - 1
            if (start > end) {
                val r = newFixedLengthResponse(Response.Status.RANGE_NOT_SATISFIABLE, "text/plain", "")
                r.addHeader("Content-Range", "bytes */$total")
                return r
            }
            val resp = newFixedLengthResponse(
                if (range != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK,
                "application/octet-stream", TdStream(id, start, end), end - start + 1
            )
            resp.addHeader("Accept-Ranges", "bytes")
            if (range != null) resp.addHeader("Content-Range", "bytes $start-$end/$total")
            return resp
        }
    }
}

/** Reads bytes [start..end] of a Telegram file, asking TDLib to download 16 MB windows from the current position. */
class TdStream(private val id: Int, start: Long, private val end: Long) : InputStream() {
    private var pos = start
    private var raf: RandomAccessFile? = null
    private var rafPath = ""
    private var knownEnd = -1L
    private var lastReq = -1L
    private var lastReqAt = 0L
    @Volatile private var closed = false

    override fun read(): Int {
        val b = ByteArray(1)
        return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xff
    }

    private fun readNow(b: ByteArray, off: Int, len: Int, limit: Long): Int {
        val n = minOf(len.toLong(), limit - pos, end - pos + 1).toInt()
        val r = raf!!
        r.seek(pos)
        val got = r.read(b, off, n)
        if (got > 0) pos += got
        return got
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos > end) return -1
        if (raf != null && pos < knownEnd) {
            val g = readNow(b, off, len, knownEnd)
            if (g > 0) return g
        }
        val deadline = System.currentTimeMillis() + 90_000
        while (!closed) {
            val f = Tg.file(id)
            val l = f.local
            var avail = 0L
            if (l.path.isNotEmpty()) {
                if (l.isDownloadingCompleted) avail = f.size - pos
                else if (pos >= l.downloadOffset && pos < l.downloadOffset + l.downloadedPrefixSize)
                    avail = l.downloadOffset + l.downloadedPrefixSize - pos
            }
            if (avail > 0) {
                if (raf == null || rafPath != l.path) {
                    raf?.close()
                    raf = RandomAccessFile(l.path, "r")
                    rafPath = l.path
                }
                knownEnd = pos + avail
                val g = readNow(b, off, len, knownEnd)
                if (g > 0) return g
            }
            if (!l.isDownloadingCompleted) {
                val inRange = pos >= l.downloadOffset && pos <= l.downloadOffset + l.downloadedPrefixSize + 2_000_000
                val now = System.currentTimeMillis()
                if (!(l.isDownloadingActive && inRange) && (lastReq != pos || now - lastReqAt > 3000)) {
                    Tg.download(id, pos, 16L * 1024 * 1024)
                    lastReq = pos
                    lastReqAt = now
                }
            }
            if (System.currentTimeMillis() > deadline) throw IOException("Telegram download timeout")
            Thread.sleep(80)
        }
        return -1
    }

    override fun close() {
        closed = true
        try { raf?.close() } catch (_: Exception) {}
    }
}
