package com.telestream

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Remembers how far you got in each video (resume, watched ticks, continue watching). */
object Progress {
    private lateinit var sp: SharedPreferences
    var version by mutableIntStateOf(0)

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    }

    private fun key(chatId: Long, msgId: Long) = chatId.toString() + ":" + msgId

    fun save(v: Tg.Vid, pos: Long, len: Long) {
        if (len <= 0L || pos < 3000L) return
        sp.edit().putString(key(v.chatId, v.msgId), "$pos,$len,${System.currentTimeMillis()}").apply()
        version++
    }

    private fun parts(v: Tg.Vid): List<String>? {
        val s = sp.getString(key(v.chatId, v.msgId), null) ?: return null
        val p = s.split(',')
        return if (p.size >= 3) p else null
    }

    /** 0..1, how much of the video was watched (0 if never played). */
    fun fraction(v: Tg.Vid): Float {
        val unused = version
        val p = parts(v) ?: return 0f
        val pos = p[0].toLongOrNull() ?: return 0f
        val len = p[1].toLongOrNull() ?: return 0f
        return if (len <= 0L) 0f else (pos.toFloat() / len).coerceIn(0f, 1f)
    }

    /** Where to resume, in ms (0 when never played or already finished). */
    fun resumePos(v: Tg.Vid): Long {
        val p = parts(v) ?: return 0L
        val pos = p[0].toLongOrNull() ?: return 0L
        val len = p[1].toLongOrNull() ?: return 0L
        if (len <= 0L || pos.toFloat() / len >= 0.95f) return 0L
        return pos
    }

    /** Message ids of unfinished videos in this chat, newest watched first. */
    fun recent(chatId: Long): List<Long> {
        val out = ArrayList<Triple<Long, Float, Long>>()
        for ((k, value) in sp.all) {
            val s = value as? String ?: continue
            if (!k.startsWith(chatId.toString() + ":")) continue
            val msgId = k.substringAfter(':').toLongOrNull() ?: continue
            val p = s.split(',')
            if (p.size < 3) continue
            val pos = p[0].toLongOrNull() ?: continue
            val len = p[1].toLongOrNull() ?: continue
            val ts = p[2].toLongOrNull() ?: continue
            if (len <= 0L) continue
            val f = pos.toFloat() / len
            if (pos > 10_000L && f < 0.95f) out.add(Triple(msgId, f, ts))
        }
        return out.sortedByDescending { it.third }.take(12).map { it.first }
    }
}
