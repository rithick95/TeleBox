plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.telestream"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gram.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        val apiId = (System.getenv("TG_API_ID") ?: "").ifBlank { "0" }
        val apiHash = System.getenv("TG_API_HASH") ?: ""
        buildConfigField("int", "TG_API_ID", apiId)
        buildConfigField("String", "TG_API_HASH", "\"$apiHash\"")
        val tmdbKey = System.getenv("TMDB_KEY") ?: ""
        buildConfigField("String", "TMDB_KEY", "\"$tmdbKey\"")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("org.videolan.android:libvlc-all:3.6.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.github.fazilus:tdlib-android:1.8.61")
}
